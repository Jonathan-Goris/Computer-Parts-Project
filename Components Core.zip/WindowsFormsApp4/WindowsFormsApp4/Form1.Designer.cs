﻿namespace WindowsFormsApp4
{
    partial class productForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.pnlOnCase = new System.Windows.Forms.Panel();
            this.pnlOnPsu = new System.Windows.Forms.Panel();
            this.pnlOnCool = new System.Windows.Forms.Panel();
            this.pnlOnGpu = new System.Windows.Forms.Panel();
            this.pnlOnMem = new System.Windows.Forms.Panel();
            this.pnlOnMobo = new System.Windows.Forms.Panel();
            this.pnlOnCpu = new System.Windows.Forms.Panel();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlCpu = new System.Windows.Forms.Panel();
            this.pnlMobo = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.button8 = new System.Windows.Forms.Button();
            this.panel11 = new System.Windows.Forms.Panel();
            this.button9 = new System.Windows.Forms.Button();
            this.panel12 = new System.Windows.Forms.Panel();
            this.button10 = new System.Windows.Forms.Button();
            this.panel13 = new System.Windows.Forms.Panel();
            this.button11 = new System.Windows.Forms.Button();
            this.panel14 = new System.Windows.Forms.Panel();
            this.button12 = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.btnCpu5 = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.btnCpu4 = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btnCpu3 = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnCpu2 = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnCpu1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.pnlCpu.SuspendLayout();
            this.pnlMobo.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.pnlOnCase);
            this.panel1.Controls.Add(this.pnlOnPsu);
            this.panel1.Controls.Add(this.pnlOnCool);
            this.panel1.Controls.Add(this.pnlOnGpu);
            this.panel1.Controls.Add(this.pnlOnMem);
            this.panel1.Controls.Add(this.pnlOnMobo);
            this.panel1.Controls.Add(this.pnlOnCpu);
            this.panel1.Controls.Add(this.button7);
            this.panel1.Controls.Add(this.button6);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(229, 687);
            this.panel1.TabIndex = 0;
            // 
            // pnlOnCase
            // 
            this.pnlOnCase.BackColor = System.Drawing.Color.White;
            this.pnlOnCase.Location = new System.Drawing.Point(219, 512);
            this.pnlOnCase.Name = "pnlOnCase";
            this.pnlOnCase.Size = new System.Drawing.Size(10, 43);
            this.pnlOnCase.TabIndex = 13;
            // 
            // pnlOnPsu
            // 
            this.pnlOnPsu.BackColor = System.Drawing.Color.White;
            this.pnlOnPsu.Location = new System.Drawing.Point(219, 442);
            this.pnlOnPsu.Name = "pnlOnPsu";
            this.pnlOnPsu.Size = new System.Drawing.Size(10, 43);
            this.pnlOnPsu.TabIndex = 12;
            // 
            // pnlOnCool
            // 
            this.pnlOnCool.BackColor = System.Drawing.Color.White;
            this.pnlOnCool.Location = new System.Drawing.Point(219, 368);
            this.pnlOnCool.Name = "pnlOnCool";
            this.pnlOnCool.Size = new System.Drawing.Size(10, 43);
            this.pnlOnCool.TabIndex = 11;
            // 
            // pnlOnGpu
            // 
            this.pnlOnGpu.BackColor = System.Drawing.Color.White;
            this.pnlOnGpu.Location = new System.Drawing.Point(219, 292);
            this.pnlOnGpu.Name = "pnlOnGpu";
            this.pnlOnGpu.Size = new System.Drawing.Size(10, 43);
            this.pnlOnGpu.TabIndex = 10;
            // 
            // pnlOnMem
            // 
            this.pnlOnMem.BackColor = System.Drawing.Color.White;
            this.pnlOnMem.Location = new System.Drawing.Point(219, 225);
            this.pnlOnMem.Name = "pnlOnMem";
            this.pnlOnMem.Size = new System.Drawing.Size(10, 43);
            this.pnlOnMem.TabIndex = 9;
            // 
            // pnlOnMobo
            // 
            this.pnlOnMobo.BackColor = System.Drawing.Color.White;
            this.pnlOnMobo.Location = new System.Drawing.Point(219, 157);
            this.pnlOnMobo.Name = "pnlOnMobo";
            this.pnlOnMobo.Size = new System.Drawing.Size(10, 43);
            this.pnlOnMobo.TabIndex = 8;
            // 
            // pnlOnCpu
            // 
            this.pnlOnCpu.BackColor = System.Drawing.Color.White;
            this.pnlOnCpu.Location = new System.Drawing.Point(219, 89);
            this.pnlOnCpu.Name = "pnlOnCpu";
            this.pnlOnCpu.Size = new System.Drawing.Size(10, 43);
            this.pnlOnCpu.TabIndex = 7;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Black;
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.SystemColors.Control;
            this.button7.Image = global::WindowsFormsApp4.Properties.Resources.chassis_50;
            this.button7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button7.Location = new System.Drawing.Point(0, 512);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(229, 43);
            this.button7.TabIndex = 6;
            this.button7.Text = "  Chasis";
            this.button7.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button7.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Black;
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.SystemColors.Control;
            this.button6.Image = global::WindowsFormsApp4.Properties.Resources.power_supply_50;
            this.button6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button6.Location = new System.Drawing.Point(0, 442);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(229, 43);
            this.button6.TabIndex = 5;
            this.button6.Text = "  Power Supply";
            this.button6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button6.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Black;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.SystemColors.Control;
            this.button5.Image = global::WindowsFormsApp4.Properties.Resources.case_fan_50;
            this.button5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.Location = new System.Drawing.Point(3, 368);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(229, 43);
            this.button5.TabIndex = 4;
            this.button5.Text = "  Cooling";
            this.button5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Black;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.SystemColors.Control;
            this.button4.Image = global::WindowsFormsApp4.Properties.Resources.video_card_50;
            this.button4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.Location = new System.Drawing.Point(0, 292);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(229, 43);
            this.button4.TabIndex = 3;
            this.button4.Text = "  Graphics Card";
            this.button4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Black;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.SystemColors.Control;
            this.button3.Image = global::WindowsFormsApp4.Properties.Resources.memory_50;
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.Location = new System.Drawing.Point(0, 225);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(229, 43);
            this.button3.TabIndex = 2;
            this.button3.Text = "  Memory";
            this.button3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Black;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.Control;
            this.button2.Image = global::WindowsFormsApp4.Properties.Resources.motherboard_50;
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(0, 157);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(229, 43);
            this.button2.TabIndex = 1;
            this.button2.Text = "  Motherboard";
            this.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Black;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.Control;
            this.button1.Image = global::WindowsFormsApp4.Properties.Resources.processor_50;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(0, 89);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(229, 43);
            this.button1.TabIndex = 0;
            this.button1.Text = "  Processor";
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(229, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(935, 83);
            this.panel2.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(704, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 18);
            this.label2.TabIndex = 1;
            this.label2.Text = "Logged in as";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Trebuchet MS", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(15, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(308, 43);
            this.label1.TabIndex = 0;
            this.label1.Text = "Components Core";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // pnlCpu
            // 
            this.pnlCpu.Controls.Add(this.pnlMobo);
            this.pnlCpu.Controls.Add(this.panel8);
            this.pnlCpu.Controls.Add(this.panel7);
            this.pnlCpu.Controls.Add(this.panel6);
            this.pnlCpu.Controls.Add(this.panel5);
            this.pnlCpu.Controls.Add(this.panel4);
            this.pnlCpu.Location = new System.Drawing.Point(229, 83);
            this.pnlCpu.Name = "pnlCpu";
            this.pnlCpu.Size = new System.Drawing.Size(935, 604);
            this.pnlCpu.TabIndex = 2;
            this.pnlCpu.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // pnlMobo
            // 
            this.pnlMobo.Controls.Add(this.panel10);
            this.pnlMobo.Controls.Add(this.panel11);
            this.pnlMobo.Controls.Add(this.panel12);
            this.pnlMobo.Controls.Add(this.panel13);
            this.pnlMobo.Controls.Add(this.panel14);
            this.pnlMobo.Location = new System.Drawing.Point(0, 0);
            this.pnlMobo.Name = "pnlMobo";
            this.pnlMobo.Size = new System.Drawing.Size(935, 604);
            this.pnlMobo.TabIndex = 5;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.button8);
            this.panel10.Location = new System.Drawing.Point(346, 303);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(237, 233);
            this.panel10.TabIndex = 4;
            // 
            // button8
            // 
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Image = global::WindowsFormsApp4.Properties.Resources._13_145_090_V01_40;
            this.button8.Location = new System.Drawing.Point(3, 3);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(231, 230);
            this.button8.TabIndex = 0;
            this.button8.Text = "GIGABYTE Z390 AORUS ULTRA";
            this.button8.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button8.UseVisualStyleBackColor = true;
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.button9);
            this.panel11.Location = new System.Drawing.Point(23, 300);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(237, 233);
            this.panel11.TabIndex = 3;
            // 
            // button9
            // 
            this.button9.FlatAppearance.BorderSize = 0;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Image = global::WindowsFormsApp4.Properties.Resources._13_145_089_V08_40;
            this.button9.Location = new System.Drawing.Point(3, 3);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(231, 230);
            this.button9.TabIndex = 0;
            this.button9.Text = "GIGABYTE Z390 AORUS MASTER";
            this.button9.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button9.UseVisualStyleBackColor = true;
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.button10);
            this.panel12.Location = new System.Drawing.Point(668, 19);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(237, 233);
            this.panel12.TabIndex = 2;
            // 
            // button10
            // 
            this.button10.FlatAppearance.BorderSize = 0;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Image = global::WindowsFormsApp4.Properties.Resources._13_144_214_V01_40;
            this.button10.Location = new System.Drawing.Point(3, 0);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(231, 230);
            this.button10.TabIndex = 0;
            this.button10.Text = "MSI MPG Z390M GAMING EDGE";
            this.button10.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button10.UseVisualStyleBackColor = true;
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.button11);
            this.panel13.Location = new System.Drawing.Point(346, 19);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(237, 233);
            this.panel13.TabIndex = 1;
            // 
            // button11
            // 
            this.button11.FlatAppearance.BorderSize = 0;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Image = global::WindowsFormsApp4.Properties.Resources._13_144_211_V80_40;
            this.button11.Location = new System.Drawing.Point(3, 3);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(231, 230);
            this.button11.TabIndex = 0;
            this.button11.Text = "MSI MPG Z390 GAMING PRO CARBON AC";
            this.button11.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button11.UseVisualStyleBackColor = true;
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.button12);
            this.panel14.Location = new System.Drawing.Point(23, 19);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(237, 233);
            this.panel14.TabIndex = 0;
            // 
            // button12
            // 
            this.button12.FlatAppearance.BorderSize = 0;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Image = global::WindowsFormsApp4.Properties.Resources._13_144_209_V80_40;
            this.button12.Location = new System.Drawing.Point(3, 0);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(231, 230);
            this.button12.TabIndex = 0;
            this.button12.Text = "MSI MEG Z390 GODLIKE";
            this.button12.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button12.UseVisualStyleBackColor = true;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.btnCpu5);
            this.panel8.Location = new System.Drawing.Point(346, 303);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(237, 233);
            this.panel8.TabIndex = 4;
            // 
            // btnCpu5
            // 
            this.btnCpu5.FlatAppearance.BorderSize = 0;
            this.btnCpu5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCpu5.Image = global::WindowsFormsApp4.Properties.Resources._19_118_024_V01_19;
            this.btnCpu5.Location = new System.Drawing.Point(3, 3);
            this.btnCpu5.Name = "btnCpu5";
            this.btnCpu5.Size = new System.Drawing.Size(231, 230);
            this.btnCpu5.TabIndex = 0;
            this.btnCpu5.Text = "Intel Core i9-9700";
            this.btnCpu5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnCpu5.UseVisualStyleBackColor = true;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.btnCpu4);
            this.panel7.Location = new System.Drawing.Point(23, 300);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(237, 233);
            this.panel7.TabIndex = 3;
            // 
            // btnCpu4
            // 
            this.btnCpu4.FlatAppearance.BorderSize = 0;
            this.btnCpu4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCpu4.Image = global::WindowsFormsApp4.Properties.Resources._19_118_024_V01_19;
            this.btnCpu4.Location = new System.Drawing.Point(3, 3);
            this.btnCpu4.Name = "btnCpu4";
            this.btnCpu4.Size = new System.Drawing.Size(231, 230);
            this.btnCpu4.TabIndex = 0;
            this.btnCpu4.Text = "Intel Core i9-9700k";
            this.btnCpu4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnCpu4.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.btnCpu3);
            this.panel6.Location = new System.Drawing.Point(668, 19);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(237, 233);
            this.panel6.TabIndex = 2;
            // 
            // btnCpu3
            // 
            this.btnCpu3.FlatAppearance.BorderSize = 0;
            this.btnCpu3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCpu3.Image = global::WindowsFormsApp4.Properties.Resources._19_118_023_V01_19;
            this.btnCpu3.Location = new System.Drawing.Point(3, 0);
            this.btnCpu3.Name = "btnCpu3";
            this.btnCpu3.Size = new System.Drawing.Size(231, 230);
            this.btnCpu3.TabIndex = 0;
            this.btnCpu3.Text = "Intel Core i9-9900";
            this.btnCpu3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnCpu3.UseVisualStyleBackColor = true;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.btnCpu2);
            this.panel5.Location = new System.Drawing.Point(346, 19);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(237, 233);
            this.panel5.TabIndex = 1;
            // 
            // btnCpu2
            // 
            this.btnCpu2.FlatAppearance.BorderSize = 0;
            this.btnCpu2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCpu2.Image = global::WindowsFormsApp4.Properties.Resources._19_117_962_Z01_2_19;
            this.btnCpu2.Location = new System.Drawing.Point(3, 3);
            this.btnCpu2.Name = "btnCpu2";
            this.btnCpu2.Size = new System.Drawing.Size(231, 230);
            this.btnCpu2.TabIndex = 0;
            this.btnCpu2.Text = "Intel Core i9-9900X";
            this.btnCpu2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnCpu2.UseVisualStyleBackColor = true;
            this.btnCpu2.Click += new System.EventHandler(this.button9_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btnCpu1);
            this.panel4.Location = new System.Drawing.Point(23, 19);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(237, 233);
            this.panel4.TabIndex = 0;
            // 
            // btnCpu1
            // 
            this.btnCpu1.FlatAppearance.BorderSize = 0;
            this.btnCpu1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCpu1.Image = global::WindowsFormsApp4.Properties.Resources.i9900k_50;
            this.btnCpu1.Location = new System.Drawing.Point(3, 3);
            this.btnCpu1.Name = "btnCpu1";
            this.btnCpu1.Size = new System.Drawing.Size(231, 230);
            this.btnCpu1.TabIndex = 0;
            this.btnCpu1.Text = "Intel Core i9-9900k";
            this.btnCpu1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnCpu1.UseVisualStyleBackColor = true;
            this.btnCpu1.Click += new System.EventHandler(this.btnCpu1_Click);
            // 
            // productForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1164, 687);
            this.Controls.Add(this.pnlCpu);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "productForm";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.pnlCpu.ResumeLayout(false);
            this.pnlMobo.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Panel pnlCpu;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnCpu1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btnCpu2;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button btnCpu3;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button btnCpu4;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Button btnCpu5;
        private System.Windows.Forms.Panel pnlMobo;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Panel pnlOnCase;
        private System.Windows.Forms.Panel pnlOnPsu;
        private System.Windows.Forms.Panel pnlOnCool;
        private System.Windows.Forms.Panel pnlOnGpu;
        private System.Windows.Forms.Panel pnlOnMem;
        private System.Windows.Forms.Panel pnlOnMobo;
        private System.Windows.Forms.Panel pnlOnCpu;
    }
}

