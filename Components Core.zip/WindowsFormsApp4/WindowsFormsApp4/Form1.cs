﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class productForm : Form
    {
        public productForm()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            pnlOnCpu.Height = button1.Height;
            pnlOnCpu.Top = button1.Top;
            pnlCpu.Visible = true;
            pnlMobo.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pnlOnMobo.Height = button2.Height;
            pnlOnMobo.Top = button2.Top;
            pnlMobo.Visible = true;
            pnlCpu.Visible = false;
        }

        private void btnCpu1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Name: Intel Core i9-9900K " +
                "\n Brand: Intel " +
                "\n Series: Core i9 9th Gen" +
                "\n Model: BX80684I99900K" +
                "\n CPU Socket Type: LGA 1151(300 Series)" +
                "\n Core Name: Coffee Lake" +
                "\n # of Cores: 8" +
                "\n # of Threads: 16" +
                "\n Operating Frequence: 3.6 GHz" +
                "\n Max Turbo Frequency: 5.0 GHz" +
                "\n L3 Cache: 16 MB" +
                "\n Memory Type: DDR4 2666" +
                "\n Integrated Graphics: Intel UHD Graphics 630" +
                "\n Thermal Design Power: 95W");
        }
        private void btnCpu2_Click (object sender, EventArgs e)
        {
            MessageBox.Show("Name: Intel Core i9-9900X" +
                "\n Brand: Intel" +
                "\n Series: Core i9 X - Series" +
                "\n Model: BX80673I99900X" +
                "\n CPU Socket Type: LGA 2066" +
                "\n Core Name: Skylake X" +
                "\n # of Cores: 10" +
                "\n # of Threads: 20" +
                "\n Operating Frequence: 3.5 GHz" +
                "\n Max Turbo Frequency: 4.4 GHz" +
                "\n L3 Cache: 19.25 MB" +
                "\n Memory Type: DDR4 2666" +
                "\n Integrated Graphics: None Listed" +
                "\n Thermal Design Power: 165W");
        }
    }
}
