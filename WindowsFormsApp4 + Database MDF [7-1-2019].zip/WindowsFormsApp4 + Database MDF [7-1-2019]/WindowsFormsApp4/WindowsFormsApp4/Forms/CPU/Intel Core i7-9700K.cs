﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp4.Forms
{
    public partial class Intel_Core_i7_9700K : Form
    {
        DataTable Products = new DataTable();
        SqlConnection myConn = new SqlConnection();
        SqlCommand myCommand = new SqlCommand();
        public Intel_Core_i7_9700K()
        {
            InitializeComponent();
            myConn.ConnectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\diazj\\Desktop\\Project Database.mdf;Integrated Security=True;Connect Timeout=30";
            myConn.Open();

            myCommand.CommandText = "Select Description, Price from Products where id = 4";

            myCommand.Connection = myConn;

            SqlDataAdapter myAdapter = new SqlDataAdapter();
            myAdapter.SelectCommand = myCommand;
            myAdapter.Fill(Products);

            PriceLabel.Text = Products.Rows[0]["Price"].ToString();
            DescriptionLabel.Text = Products.Rows[0]["Description"].ToString();
        }
    }
}
