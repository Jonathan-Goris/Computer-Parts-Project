﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace WindowsFormsApp4
{
    public partial class Form2 : Form
    {
        DataTable Products = new DataTable();
        SqlConnection myConn = new SqlConnection();
        SqlCommand myCommand = new SqlCommand();

        private void Form2_Load(object sender, EventArgs e)
        {
            myConn.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=" +
                "C:\\USERS\\MIKE\\DESKTOP\\WINDOWSFORMSAPP4\\WINDOWSFORMSAPP4\\PROJECT DATABASE.MDF" +
                ";Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;" +
                "ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            myConn.Open();

            myCommand.CommandText = "Select Price from Products where Id = @Id";
            myCommand.Connection = myConn;

            SqlDataAdapter myAdapter = new SqlDataAdapter();
            myAdapter.Fill(Products);

            PriceLabel.Text = Products.Rows[0]["Price"].ToString();
            DescriptionLabel.Text = Products.Rows[0]["Description"].ToString();
        }

        public Form2()
        {
            InitializeComponent();
        }
    }
}
