﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp4
{
    public partial class productForm : Form
    {
        DataTable Products = new DataTable();
        SqlConnection myConn = new SqlConnection();
        SqlCommand myCommand = new SqlCommand(); 

        private void productForm_Load(object sender, EventArgs e)
        {
            myConn.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=" + 
                "C:\\USERS\\MIKE\\DESKTOP\\WINDOWSFORMSAPP4\\WINDOWSFORMSAPP4\\PROJECT DATABASE.MDF" + 
                ";Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;" +
                "ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            myConn.Open();

            myCommand.CommandText = "Select * from Products";
            myCommand.Connection = myConn;

            SqlDataAdapter myAdapter = new SqlDataAdapter();
            myAdapter.Fill(Products);
        }

        public productForm()
        {
            InitializeComponent();
            pnlCpu.Visible = false;
            pnlMobo.Visible = false;
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        //------------------------------------------------------------------------------------------

        //CODE FOR LEFT PANEL
        private void button1_Click(object sender, EventArgs e)
        {
            pnlOnCpu.Height = button1.Height;
            pnlOnCpu.Top = button1.Top;

            pnlCpu.Visible = true;
            pnlMobo.Visible = false;
            pnlMem.Visible = false;
            pnlGpu.Visible = false;
            pnlCool.Visible = false;
            pnlPsu.Visible = false;
            panel3.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pnlOnMobo.Height = button2.Height;
            pnlOnMobo.Top = button2.Top;  
            
            pnlMobo.Visible = true;
            pnlMem.Visible = false;
            pnlGpu.Visible = false;
            pnlCool.Visible = false;
            pnlPsu.Visible = false;
            panel3.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            pnlOnMem.Height = button3.Height;
            pnlOnMem.Top = button3.Top;

            pnlMem.Visible = true;
            pnlGpu.Visible = false;
            pnlCool.Visible = false;
            pnlPsu.Visible = false;
            panel3.Visible = false;
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            pnlOnGpu.Height = button4.Height;
            pnlOnGpu.Top = button4.Top;

            pnlGpu.Visible = true;
            pnlCool.Visible = false;
            pnlPsu.Visible = false;
            panel3.Visible = false;
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            pnlOnCool.Height = button5.Height;
            pnlOnCool.Top = button5.Top;

            pnlCool.Visible = true;
            pnlPsu.Visible = false;
            panel3.Visible = false;
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            pnlOnPsu.Height = button6.Height;
            pnlOnPsu.Top = button6.Top;

            pnlPsu.Visible = true;
            panel3.Visible = false;
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            pnlOnCase.Height = button7.Height;
            pnlOnCase.Top = button7.Top;

            panel3.Visible = true;
        }

        //------------------------------------------------------------------------------------------

        //CODE FOR CPU BUTTONS
        private void btnCpu1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(" Name: Intel Core i9-9900K " +
                "\n Brand: Intel " +
                "\n Series: Core i9 9th Gen" +
                "\n Model: BX80684I99900K" +
                "\n CPU Socket Type: LGA 1151(300 Series)" +
                "\n Core Name: Coffee Lake" +
                "\n # of Cores: 8" +
                "\n # of Threads: 16" +
                "\n Operating Frequence: 3.6 GHz" +
                "\n Max Turbo Frequency: 5.0 GHz" +
                "\n L3 Cache: 16 MB" +
                "\n Memory Type: DDR4 2666" +
                "\n Integrated Graphics: Intel UHD Graphics 630" +
                "\n Thermal Design Power: 95W");
        }
        private void btnCpu2_Click (object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            addForm.ShowDialog();
            
        }

        private void btnCpu3_Click(object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            addForm.ShowDialog();
        }

        private void btnCpu4_Click(object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            addForm.ShowDialog();
        }

        private void btnCpu5_Click(object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            addForm.ShowDialog();
        }

        //------------------------------------------------------------------------------------------
        //CODE FOR MOTHERBOARD BUTTONS
        private void btnMobo1_Click(object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            addForm.ShowDialog();
        }

        private void btnMobo2_Click(object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            addForm.ShowDialog();
        }

        private void btnMobo3_Click(object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            addForm.ShowDialog();
        }

        private void btnMobo4_Click(object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            addForm.ShowDialog();
        }

        private void btnMobo5_Click(object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            addForm.ShowDialog();
        }

        //------------------------------------------------------------------------------------------
        //CODE FOR MEMORY BUTTONS
        private void btnMem1_Click(object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            addForm.ShowDialog();
        }

        private void btnMem2_Click(object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            addForm.ShowDialog();
        }

        private void btnMem3_Click(object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            addForm.ShowDialog();
        }

        private void btnMem4_Click(object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            addForm.ShowDialog();
        }

        private void btnMem5_Click(object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            addForm.ShowDialog();
        }

        //------------------------------------------------------------------------------------------
        //CODE FOR GRAPHICS_CARD BUTTONS
        private void btnGpu1_Click(object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            addForm.ShowDialog();
        }

        private void btnGpu2_Click(object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            addForm.ShowDialog();
        }

        private void btnGpu3_Click(object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            addForm.ShowDialog();
        }

        private void btnGpu4_Click(object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            addForm.ShowDialog();
        }

        private void btnGpu5_Click(object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            addForm.ShowDialog();
        }

        //------------------------------------------------------------------------------------------
        //CODE FOR COOLING BUTTONS
        private void btnCool1_Click(object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            addForm.ShowDialog();
        }

        private void btnCool2_Click(object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            addForm.ShowDialog();
        }

        private void btnCool3_Click(object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            addForm.ShowDialog();
        }

        private void btnCool4_Click(object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            addForm.ShowDialog();
        }

        private void btnCool5_Click(object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            addForm.ShowDialog();
        }

        //------------------------------------------------------------------------------------------
        //CODE FOR POWER_SUPPLY BUTTONS
        private void btnPsu1_Click(object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            addForm.ShowDialog();
        }

        private void btnPsu2_Click(object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            addForm.ShowDialog();
        }

        private void btnPsu3_Click(object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            addForm.ShowDialog();
        }

        private void btnPsu4_Click(object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            addForm.ShowDialog();
        }

        private void btnPsu5_Click(object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            addForm.ShowDialog();
        }

        //------------------------------------------------------------------------------------------
        //CODE FOR CHASSIS BUTTONS
        private void BtnChassis1_Click(object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            addForm.ShowDialog();
        }

        private void BtnChassis2_Click(object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            addForm.ShowDialog();
        }

        private void BtnChassis3_Click(object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            addForm.ShowDialog();
        }

        private void BtnChassis4_Click(object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            addForm.ShowDialog();
        }

        private void BtnChassis5_Click(object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            addForm.ShowDialog();
        }
    }
}
