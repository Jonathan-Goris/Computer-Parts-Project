﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using WindowsFormsApp4.Forms.Processor;
using WindowsFormsApp4.Forms.Motherboards;
using WindowsFormsApp4.Forms.Memory;
using GSkill = WindowsFormsApp4.Forms.Memory.GSkill;
using WindowsFormsApp4.Forms.Graphics_Card;
using WindowsFormsApp4.Forms.Cooling;
using WindowsFormsApp4.Forms.Chasis;
using WindowsFormsApp4.Forms.Power_Supply;

namespace WindowsFormsApp4
{
    public partial class productForm : Form
    {
        DataTable Products = new DataTable();
        SqlConnection myConn = new SqlConnection();
        SqlCommand myCommand = new SqlCommand(); 
        

        public void ProductForm_Load(object sender, EventArgs e)
        {
            myConn.ConnectionString = "Data Source = (LocalDB)\\MSSQLLocalDB; AttachDbFilename = E:\\Summer 2019\\WindowsFormsApp4\\WindowsFormsApp4\\Project Database.mdf; Integrated Security = True; Connect Timeout = 30";
            myConn.Open();

            myCommand.CommandText = "Select * from Products";
            myCommand.Connection = myConn;

            SqlDataAdapter myAdapter = new SqlDataAdapter();
            myAdapter.Fill(Products);
        }

        public productForm()
        {
            InitializeComponent();
            pnlCpu.Visible = false;
            pnlMobo.Visible = false;
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        //------------------------------------------------------------------------------------------

        //CODE FOR LEFT PANEL
        private void button1_Click(object sender, EventArgs e)
        {
            pnlOnCpu.Height = button1.Height;
            pnlOnCpu.Top = button1.Top;

            pnlCpu.Visible = true;
            pnlMobo.Visible = false;
            pnlMem.Visible = false;
            pnlGpu.Visible = false;
            pnlCool.Visible = false;
            pnlPsu.Visible = false;
            panel3.Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pnlOnMobo.Height = button2.Height;
            pnlOnMobo.Top = button2.Top;  
            
            pnlMobo.Visible = true;
            pnlMem.Visible = false;
            pnlGpu.Visible = false;
            pnlCool.Visible = false;
            pnlPsu.Visible = false;
            panel3.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            pnlOnMem.Height = button3.Height;
            pnlOnMem.Top = button3.Top;

            pnlMem.Visible = true;
            pnlGpu.Visible = false;
            pnlCool.Visible = false;
            pnlPsu.Visible = false;
            panel3.Visible = false;
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            pnlOnGpu.Height = button4.Height;
            pnlOnGpu.Top = button4.Top;

            pnlGpu.Visible = true;
            pnlCool.Visible = false;
            pnlPsu.Visible = false;
            panel3.Visible = false;
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            pnlOnCool.Height = button5.Height;
            pnlOnCool.Top = button5.Top;

            pnlCool.Visible = true;
            pnlPsu.Visible = false;
            panel3.Visible = false;
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            pnlOnPsu.Height = button6.Height;
            pnlOnPsu.Top = button6.Top;

            pnlPsu.Visible = true;
            panel3.Visible = false;
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            pnlOnCase.Height = button7.Height;
            pnlOnCase.Top = button7.Top;

            panel3.Visible = true;
        }

        //------------------------------------------------------------------------------------------

        //CODE FOR CPU BUTTONS
        private void btnCpu1_Click(object sender, EventArgs e)
        {
            Form2 addForm = new Form2();
            addForm.ShowDialog();
        }
        private void btnCpu2_Click (object sender, EventArgs e)
        {

            Intel_Core_i9_9900X addForm = new Intel_Core_i9_9900X();
            addForm.ShowDialog();
            
        }

        private void btnCpu3_Click(object sender, EventArgs e)
        {
            Intel_Core_i9_9900 addForm = new Intel_Core_i9_9900();
            addForm.ShowDialog();
        }

        private void btnCpu4_Click(object sender, EventArgs e)
        {
            Intel_Core_i7_9700K addForm = new Intel_Core_i7_9700K();
            addForm.ShowDialog();
        }

        private void btnCpu5_Click(object sender, EventArgs e)
        {
            Intel_Core_i7_9700 addForm = new Intel_Core_i7_9700();
            addForm.ShowDialog();
        }

        //------------------------------------------------------------------------------------------
        //CODE FOR MOTHERBOARD BUTTONS
        private void btnMobo1_Click(object sender, EventArgs e)
        {
            G addForm = new G();
            addForm.ShowDialog();
        }

        private void btnMobo2_Click(object sender, EventArgs e)
        {
            MSI_MPG_Z390_GAMING_PRO_CARBON_AC addForm = new MSI_MPG_Z390_GAMING_PRO_CARBON_AC();
            addForm.ShowDialog();
        }

        private void btnMobo3_Click(object sender, EventArgs e)
        {
            MSI_MPG_Z390M_GAMING_EDGE addForm = new MSI_MPG_Z390M_GAMING_EDGE();
            addForm.ShowDialog();
        }

        private void btnMobo4_Click(object sender, EventArgs e)
        {
            GIGABYTE_Z390_AORUS_MASTER addForm = new GIGABYTE_Z390_AORUS_MASTER();
            addForm.ShowDialog();
        }

        private void btnMobo5_Click(object sender, EventArgs e)
        {
            GIGABYTE_Z390_AORUS_ULTRA addForm = new GIGABYTE_Z390_AORUS_ULTRA();
            addForm.ShowDialog();
        }

        //------------------------------------------------------------------------------------------
        //CODE FOR MEMORY BUTTONS
        private void btnMem1_Click(object sender, EventArgs e)
        {
            GSkill addForm = new GSkill();
            addForm.ShowDialog();
        }

        private void btnMem2_Click(object sender, EventArgs e)
        {
            TridentZ addForm = new TridentZ();
            addForm.ShowDialog();
        }

        private void btnMem3_Click(object sender, EventArgs e)
        {
            CORSAIR_Vengeance_RGB_Pro_32GB addForm = new CORSAIR_Vengeance_RGB_Pro_32GB();
            addForm.ShowDialog();
        }

        private void btnMem4_Click(object sender, EventArgs e)
        {
            Ballistix_Sport_LT_32GB addForm = new Ballistix_Sport_LT_32GB();
            addForm.ShowDialog();
        }

        private void btnMem5_Click(object sender, EventArgs e)
        {
            Ballistix_Sport_LT_16GB addForm = new Ballistix_Sport_LT_16GB();
            addForm.ShowDialog();
        }

        //------------------------------------------------------------------------------------------
        //CODE FOR GRAPHICS_CARD BUTTONS
        private void btnGpu1_Click(object sender, EventArgs e)
        {
            ASUS_ROG_Strix_GeForce_RTX_2070 addForm = new ASUS_ROG_Strix_GeForce_RTX_2070();
            addForm.ShowDialog();
        }

        private void btnGpu2_Click(object sender, EventArgs e)
        {
            EVGA_GeForce_RTX_2060_SC_Ultra_GAMING addForm = new EVGA_GeForce_RTX_2060_SC_Ultra_GAMING();
            addForm.ShowDialog();
        }

        private void btnGpu3_Click(object sender, EventArgs e)
        {
            MSI_GeForce_GTX_1660_Ti addForm = new MSI_GeForce_GTX_1660_Ti();
            addForm.ShowDialog();
        }

        private void btnGpu4_Click(object sender, EventArgs e)
        {
            GIGABYTE_GeForce_GTX_1060 addForm = new GIGABYTE_GeForce_GTX_1060();
            addForm.ShowDialog();
        }

        private void btnGpu5_Click(object sender, EventArgs e)
        {
            MSI_GeForce_RTX_2070 addForm = new MSI_GeForce_RTX_2070();
            addForm.ShowDialog();
        }

        //------------------------------------------------------------------------------------------
        //CODE FOR COOLING BUTTONS
        private void btnCool1_Click(object sender, EventArgs e)
        {
            CORSAIR_Hydro_Series_H100i_RGB_PLATINUM addForm = new CORSAIR_Hydro_Series_H100i_RGB_PLATINUM();
            addForm.ShowDialog();
        }

        private void btnCool2_Click(object sender, EventArgs e)
        {
            Cooler_Master_MasterLiquid_ML120R addForm = new Cooler_Master_MasterLiquid_ML120R();
            addForm.ShowDialog();
        }

        private void btnCool3_Click(object sender, EventArgs e)
        {
            Cooler_Master_MasterLiquid_Lite_120 addForm = new Cooler_Master_MasterLiquid_Lite_120();
            addForm.ShowDialog();
        }

        private void btnCool4_Click(object sender, EventArgs e)
        {
            Cooler_Master_MasterLiquid_Lite_240 addForm = new Cooler_Master_MasterLiquid_Lite_240();
            addForm.ShowDialog();
        }

        private void btnCool5_Click(object sender, EventArgs e)
        {
            Cooler_Master_MasterLiquid_ML360R addForm = new Cooler_Master_MasterLiquid_ML360R();
            addForm.ShowDialog();
        }

        //------------------------------------------------------------------------------------------
        //CODE FOR POWER_SUPPLY BUTTONS
        private void btnPsu1_Click(object sender, EventArgs e)
        {
            EVGA_650 addForm = new EVGA_650();
            addForm.ShowDialog();
        }

        private void btnPsu2_Click(object sender, EventArgs e)
        {
            CORSAIR_TX_M_Series_TX550M addForm = new CORSAIR_TX_M_Series_TX550M();
            addForm.ShowDialog();
        }

        private void btnPsu3_Click(object sender, EventArgs e)
        {
            EVGA_SuperNOVA_1000_P2 addForm = new EVGA_SuperNOVA_1000_P2();
            addForm.ShowDialog();
        }

        private void btnPsu4_Click(object sender, EventArgs e)
        {
            CORSAIR_HX_Series_HX1000 addForm = new CORSAIR_HX_Series_HX1000();
            addForm.ShowDialog();
        }

        private void btnPsu5_Click(object sender, EventArgs e)
        {
            CORSAIR_AX_Series_AX1000 addForm = new CORSAIR_AX_Series_AX1000();
            addForm.ShowDialog();
        }

        //------------------------------------------------------------------------------------------
        //CODE FOR CHASSIS BUTTONS
        private void BtnChassis1_Click(object sender, EventArgs e)
        {
            Cooler_Master_MasterCase_H500M addForm = new Cooler_Master_MasterCase_H500M();
            addForm.ShowDialog();
        }

        private void BtnChassis2_Click(object sender, EventArgs e)
        {
            CORSAIR_Crystal_Series_570X_RGB addForm = new CORSAIR_Crystal_Series_570X_RGB();
            addForm.ShowDialog();
        }

        private void BtnChassis3_Click(object sender, EventArgs e)
        {
            Thermaltake_View_71_RGB addForm = new Thermaltake_View_71_RGB();
            addForm.ShowDialog();
        }

        private void BtnChassis4_Click(object sender, EventArgs e)
        {
            Corsair_Carbide_Series_275R addForm = new Corsair_Carbide_Series_275R();
            addForm.ShowDialog();
        }

        private void BtnChassis5_Click(object sender, EventArgs e)
        {
            Cooler_Master_MasterBox_E300L addForm = new Cooler_Master_MasterBox_E300L();
            addForm.ShowDialog();
        }
    }
}
