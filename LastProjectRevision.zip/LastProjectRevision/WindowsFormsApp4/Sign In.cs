﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApp4
{
    public partial class Sign_In : Form
    {
        DataTable mydt = new DataTable();
        SqlConnection myconn = new SqlConnection();
        SqlDataAdapter myadapter = new SqlDataAdapter();
        productForm page = new productForm();
        public Sign_In()
        {
            InitializeComponent();
        }
        private void SignInButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (UsernameTextBox.Text == "" && PasswordTextBox.Text == "")
                {
                    MessageBox.Show("Enter the Username and Password");
                }
                else
                {
                    myconn.ConnectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=E:\\Summer 2019\\WindowsFormsApp4\\WindowsFormsApp4\\Project Database.mdf;Integrated Security=True;Connect Timeout=30";
                    SqlCommand CMD = new SqlCommand();

                    CMD.CommandText = "Select * From Accounts Where Username = @Usname AND Password = @Paword";
                    CMD.Parameters.Add("@Usname", SqlDbType.VarChar, 50, "Username");
                    CMD.Parameters["@Usname"].Value = UsernameTextBox.Text;
                    CMD.Parameters.Add("@Paword", SqlDbType.VarChar, 50, "Password");
                    CMD.Parameters["@Paword"].Value = PasswordTextBox.Text;


                    CMD.Connection = myconn;
                    DataSet ds = new DataSet();

                    SqlDataAdapter adapt = new SqlDataAdapter(CMD);
                    myadapter.SelectCommand = CMD;
                    myadapter.Fill(ds);

                    myconn.Close();

                    int count = ds.Tables[0].Rows.Count;

                    if (count == 1)
                    {

                        page.Show();
                    }
                    else
                    {
                        MessageBox.Show("Username or Password are incorrect");
                    }
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }





        }

        private void CreateNewAccButton_Click(object sender, EventArgs e)
        {
            CreateAccount create = new CreateAccount();
            create.Show();
        }
    }
}
