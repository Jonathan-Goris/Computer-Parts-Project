﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Splash_Screen
{
    public partial class CreateAccount : Form
    {
        DataTable mydt = new DataTable();
        SqlConnection myconn = new SqlConnection();
        SqlCommand mycommand = new SqlCommand();
        SqlDataAdapter myadapter = new SqlDataAdapter();
        public CreateAccount()
        {
            InitializeComponent();
        }
       

       

        private void LastName_Enter(object sender, EventArgs e)
        {
            if (LastName.Text == "Last Name")
            {
                LastName.Text = "";
                LastName.ForeColor = Color.Black;
            }

        }

        private void LastName_Leave(object sender, EventArgs e)
        {
            if (LastName.Text == "")
            {
                LastName.Text = "Last Name";
                LastName.ForeColor = Color.LightSteelBlue;
            }
        }

        private void Email_Enter(object sender, EventArgs e)
        {
            if (Email.Text == "Email Address")
            {
                Email.Text = "";
                Email.ForeColor = Color.Black;
            }
        }

        private void Email_Leave(object sender, EventArgs e)
        {
            if (Email.Text == "")
            {
                Email.Text = "Email Address";
                Email.ForeColor = Color.LightSteelBlue;
            }
        }


        private void Password_Click(object sender, EventArgs e)
        {

            if (Password.Text == "")
            {
                Password.UseSystemPasswordChar = true;

            }
        }

        private void Password_Enter(object sender, EventArgs e)
        {
            if (Password.Text == "Password")
            {
                Password.UseSystemPasswordChar = true;
                Password.Text = "";
                Password.ForeColor = Color.Black;
            }
        }

        private void Password_Leave(object sender, EventArgs e)
        {
            if (Password.Text == "")
            {
                Password.UseSystemPasswordChar = false;
                Password.Text = "Password";
                Password.ForeColor = Color.LightSteelBlue;
            }
        }

        private void BtnCreateAccount_Click(object sender, EventArgs e)
        {
            //Validing Inputs
            if (FirstName.Text == "First Name" && LastName.Text == "Last Name" && Email.Text == "Email Address" &&  UsernameTextBox.Text == "Username" && Password.Text == "Password")
            {
                MessageBox.Show("Didn't enter aything!");
                return;
            }
            if (FirstName.Text == "First Name")
            {
                MessageBox.Show("Enter First Name");

            }
            if (LastName.Text == "Last Name")
            {
                MessageBox.Show("Enter Last Name");

            }
            if (Email.Text == "Email Address")
            {
                MessageBox.Show("Enter Email Address");

            }
            if(UsernameTextBox.Text == "Username")
            {
                MessageBox.Show("Enter a Username");
            }
            if (Password.Text == "Password")
            {
                MessageBox.Show("Enter Password");

            }



            if (FirstName.Text != "First Name" && LastName.Text != "Last Name" && Email.Text != "Email Address" && UsernameTextBox.Text !="Username" && Password.Text != "Password")
            {
                myconn.ConnectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\jonat\\source\\repos\\Splash Screen\\Project Database.mdf;Integrated Security=True;Connect Timeout=30";
                myconn.Open();

                //Insert
                mycommand = new SqlCommand("Insert INTO Accounts ( Username, Password) Values (@Uname, @Pword)", myconn);

                mycommand.Parameters.Add("@Uname", SqlDbType.VarChar, 50, "Username");
                mycommand.Parameters["@Uname"].Value = UsernameTextBox.Text;
                mycommand.Parameters.Add("@Pword", SqlDbType.VarChar, 50, "Password");
                mycommand.Parameters["@Pword"].Value = Password.Text;

                mycommand.Connection = myconn;
                myadapter.InsertCommand = mycommand;

                myadapter.Update(mydt);
                mycommand.ExecuteNonQuery();

                //Insert
               

                mycommand = new SqlCommand("Insert INTO Customers ( CustomerFirstName, CustomerLastName, CustomerEmail) Values (@firstname, @lastname, @email)", myconn);

                mycommand.Parameters.Add("@firstname", SqlDbType.VarChar, 50, "CustomerFirstName");
                mycommand.Parameters["@firstname"].Value = FirstName.Text;

                mycommand.Parameters.Add("@lastname", SqlDbType.VarChar, 50, "CustomerLastName");
                mycommand.Parameters["@lastname"].Value = LastName.Text;

                mycommand.Parameters.Add("@email", SqlDbType.VarChar);
                mycommand.Parameters["@email"].Value = Email.Text;

                mycommand.Parameters.Add("@password", SqlDbType.VarChar, 50, "CustomerEmail");
                mycommand.Parameters["@password"].Value = Password.Text;

                mycommand.Connection = myconn;
                myadapter.InsertCommand = mycommand;

                myadapter.Update(mydt);
                mycommand.ExecuteNonQuery();


                //Setting the textboxes back to orginal state
                FirstName.Text = "First Name";
                FirstName.ForeColor = Color.LightSteelBlue;
                LastName.Text = "Last Name";
                LastName.ForeColor = Color.LightSteelBlue;
                Email.Text = "Email Address";
                Email.ForeColor = Color.LightSteelBlue;
                UsernameTextBox.Text = "Email Address";
                UsernameTextBox.ForeColor = Color.LightSteelBlue;
                Password.Text = "Password";
                Password.ForeColor = Color.LightSteelBlue;
                Password.UseSystemPasswordChar = false;

                myconn.Close();
            }


        }

        private void UsernameTextBox_Enter(object sender, EventArgs e)
        {
            if (UsernameTextBox.Text == "Username")
            {
                UsernameTextBox.Text = "";
                UsernameTextBox.ForeColor = Color.Black;
            }
        }

        private void UsernameTextBox_Leave(object sender, EventArgs e)
        {
            if (UsernameTextBox.Text == "")
            {
                UsernameTextBox.UseSystemPasswordChar = false;
                UsernameTextBox.Text = "Username";
                UsernameTextBox.ForeColor = Color.LightSteelBlue;
            }
        }

        private void FirstName_Enter(object sender, EventArgs e)
        {
            if (FirstName.Text == "First Name")
            {
                FirstName.Text = "";
                FirstName.ForeColor = Color.Black;
            }
        }

        private void FirstName_Leave(object sender, EventArgs e)
        {
            if (FirstName.Text == "")
            {
                FirstName.Text = "First Name";
                FirstName.ForeColor = Color.LightSteelBlue;
            }
        }
    }
}
