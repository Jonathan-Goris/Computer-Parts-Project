﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp4
{

    public partial class Purchase_History : Form
    {
        DataTable Customers = new DataTable();
        SqlConnection myConn = new SqlConnection();
        SqlCommand myCommand = new SqlCommand();
        SqlDataAdapter myAdapter = new SqlDataAdapter();

        public Purchase_History()
        {
            InitializeComponent();
            myConn.ConnectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\diazj\\Desktop\\LastProjectRevision\\LastProjectRevision\\WindowsFormsApp4\\Project Database.mdf;Integrated Security=True;Connect Timeout=30";
            myConn.Open();

            myCommand.CommandText = "Select * from Customers";

            myCommand.Connection = myConn;


            myAdapter.SelectCommand = myCommand;
            myAdapter.Fill(Customers);
            dataGridView1.DataSource = Customers;

            this.dataGridView1.Columns["Id"].Visible = false;
        }
    }
}
