﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp4.Forms.Memory
{
    public partial class Ballistix_Sport_LT_16GB : Form
    {
        DataTable Products = new DataTable();
        SqlConnection myConn = new SqlConnection();
        SqlCommand myCommand = new SqlCommand();
        SqlDataAdapter myadapter = new SqlDataAdapter();
        public Ballistix_Sport_LT_16GB()
        {
            InitializeComponent();
            myConn.ConnectionString = "Data Source = (LocalDB)\\MSSQLLocalDB; AttachDbFilename = E:\\Summer 2019\\WindowsFormsApp4\\WindowsFormsApp4\\Project Database.mdf; Integrated Security = True; Connect Timeout = 30";
            myConn.Open();

            myCommand.CommandText = "Select Price, Description from Products WHERE Id = 46";
            myCommand.Connection = myConn;

            myadapter.SelectCommand = myCommand;
            myadapter.Fill(Products);


            PriceLabel.Text = Products.Rows[0]["Price"].ToString();
            DescriptionLabel.Text = Products.Rows[0]["Description"].ToString();
        }

        private void AddBtn_Click(object sender, EventArgs e)
        {
            myCommand = new SqlCommand("INSERT INTO AddCartTable (ProductName, Price, Description) VALUES (@productn, @price, @Descript)", myConn);
            myCommand.Parameters.Add("@productn", SqlDbType.VarChar);
            myCommand.Parameters.Add("@price", SqlDbType.Money);
            myCommand.Parameters.Add("@Descript", SqlDbType.VarChar);

            myCommand.Parameters["@productn"].Value = "Intel Core i9-9900K";
            myCommand.Parameters["@price"].Value = PriceLabel.Text;
            myCommand.Parameters["@Descript"].Value = DescriptionLabel.Text;

            myCommand.ExecuteNonQuery();

            MessageBox.Show("Added To the Cart");
            myConn.Close();
        }

        private void CancelBtn_Click(object sender, EventArgs e)
        {
            Ballistix_Sport_LT_16GB addForm = new Ballistix_Sport_LT_16GB();
            addForm.Close();
        }
    }
}
