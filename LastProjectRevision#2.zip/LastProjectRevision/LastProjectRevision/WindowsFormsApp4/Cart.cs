﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp4
{
    public partial class Cart : Form
    {
        DataTable Products = new DataTable();
        SqlConnection myConn = new SqlConnection();
        SqlCommand myCommand = new SqlCommand();
        SqlDataAdapter myAdapter = new SqlDataAdapter();
        String Total;
        public Cart()
        {
            InitializeComponent();
            textBox3.Text = Sign_In.SetValueForText1;
            myConn.ConnectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\diazj\\Desktop\\LastProjectRevision\\LastProjectRevision\\WindowsFormsApp4\\Project Database.mdf;Integrated Security=True;Connect Timeout=30";
            myConn.Open();

            myCommand.CommandText = "Select * from AddCartTable";

            myCommand.Connection = myConn;


            myAdapter.SelectCommand = myCommand;
            myAdapter.Fill(Products);
            dataGridView1.DataSource = Products;

            this.dataGridView1.Columns["Id"].Visible = false;


            //Tax
            double sum = 0;
            for (int i = 0; i < dataGridView1.Rows.Count; ++i)
            {
                sum += Convert.ToDouble(dataGridView1.Rows[i].Cells[2].Value);
            }

            double addTax = (sum * 0.0825);
            String tax = string.Format("{0:0.00}", addTax);
            textBox1.Text = "$" + tax;


            //Total
            double withTaxTotal = addTax + sum;
            Total = string.Format("{0:0.00}", withTaxTotal);
            textBox2.Text = "$" + Total;
        }

        private void btn_Checkout(object sender, EventArgs e)
        {
            //Insert
            myCommand = new SqlCommand("Insert into Customers (Username,Product,TotalPurchasePrice) values (@username,@product, @totalpurchaseprice)", myConn);

           
            double ttp = Convert.ToDouble(Total);
            myCommand.Parameters.Add("@username", SqlDbType.VarChar);
            myCommand.Parameters["@username"].Value = textBox3.Text;
            myCommand.Parameters.Add("@totalpurchaseprice", SqlDbType.Int);
            myCommand.Parameters["@totalpurchaseprice"].Value = ttp;


            myCommand.Parameters.Add("@product", SqlDbType.VarChar);
            myCommand.Parameters["@product"].Value = dataGridView1.Rows[0].Cells[1].Value;


            myCommand.ExecuteNonQuery();
            MessageBox.Show("Item(s) Checked Out." + "\n" + "\n" + "Thank you for your Purchase!");
            this.Close();
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            //Delete
            myCommand = new SqlCommand("DELETE FROM AddCartTable", myConn);
            myCommand.Connection = myConn;
            myAdapter.DeleteCommand = myCommand;
            myCommand.ExecuteNonQuery();
            MessageBox.Show("Cart Cleared!");
            this.Close();


        }
    }
}

