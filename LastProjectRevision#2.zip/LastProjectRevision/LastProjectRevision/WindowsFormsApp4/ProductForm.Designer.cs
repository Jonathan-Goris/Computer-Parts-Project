﻿namespace WindowsFormsApp4
{
    partial class productForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.pnlOnCase = new System.Windows.Forms.Panel();
            this.pnlOnPsu = new System.Windows.Forms.Panel();
            this.pnlOnCool = new System.Windows.Forms.Panel();
            this.pnlOnGpu = new System.Windows.Forms.Panel();
            this.pnlOnMem = new System.Windows.Forms.Panel();
            this.pnlOnMobo = new System.Windows.Forms.Panel();
            this.pnlOnCpu = new System.Windows.Forms.Panel();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlCpu = new System.Windows.Forms.Panel();
            this.pnlMobo = new System.Windows.Forms.Panel();
            this.pnlMem = new System.Windows.Forms.Panel();
            this.pnlGpu = new System.Windows.Forms.Panel();
            this.pnlCool = new System.Windows.Forms.Panel();
            this.pnlPsu = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel34 = new System.Windows.Forms.Panel();
            this.BtnChassis5 = new System.Windows.Forms.Button();
            this.panel35 = new System.Windows.Forms.Panel();
            this.BtnChassis4 = new System.Windows.Forms.Button();
            this.panel36 = new System.Windows.Forms.Panel();
            this.BtnChassis3 = new System.Windows.Forms.Button();
            this.panel37 = new System.Windows.Forms.Panel();
            this.BtnChassis2 = new System.Windows.Forms.Button();
            this.panel38 = new System.Windows.Forms.Panel();
            this.BtnChassis1 = new System.Windows.Forms.Button();
            this.panel29 = new System.Windows.Forms.Panel();
            this.btnPsu5 = new System.Windows.Forms.Button();
            this.panel30 = new System.Windows.Forms.Panel();
            this.btnPsu4 = new System.Windows.Forms.Button();
            this.panel31 = new System.Windows.Forms.Panel();
            this.btnPsu3 = new System.Windows.Forms.Button();
            this.panel32 = new System.Windows.Forms.Panel();
            this.btnPsu2 = new System.Windows.Forms.Button();
            this.panel33 = new System.Windows.Forms.Panel();
            this.btnPsu1 = new System.Windows.Forms.Button();
            this.panel24 = new System.Windows.Forms.Panel();
            this.btnCool5 = new System.Windows.Forms.Button();
            this.panel25 = new System.Windows.Forms.Panel();
            this.btnCool4 = new System.Windows.Forms.Button();
            this.panel26 = new System.Windows.Forms.Panel();
            this.btnCool3 = new System.Windows.Forms.Button();
            this.panel27 = new System.Windows.Forms.Panel();
            this.btnCool2 = new System.Windows.Forms.Button();
            this.panel28 = new System.Windows.Forms.Panel();
            this.btnCool1 = new System.Windows.Forms.Button();
            this.panel19 = new System.Windows.Forms.Panel();
            this.btnGpu5 = new System.Windows.Forms.Button();
            this.panel20 = new System.Windows.Forms.Panel();
            this.btnGpu4 = new System.Windows.Forms.Button();
            this.panel21 = new System.Windows.Forms.Panel();
            this.btnGpu3 = new System.Windows.Forms.Button();
            this.panel22 = new System.Windows.Forms.Panel();
            this.btnGpu2 = new System.Windows.Forms.Button();
            this.panel23 = new System.Windows.Forms.Panel();
            this.btnGpu1 = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.btnMem5 = new System.Windows.Forms.Button();
            this.panel15 = new System.Windows.Forms.Panel();
            this.btnMem4 = new System.Windows.Forms.Button();
            this.panel16 = new System.Windows.Forms.Panel();
            this.btnMem3 = new System.Windows.Forms.Button();
            this.panel17 = new System.Windows.Forms.Panel();
            this.btnMem2 = new System.Windows.Forms.Button();
            this.panel18 = new System.Windows.Forms.Panel();
            this.btnMem1 = new System.Windows.Forms.Button();
            this.panel10 = new System.Windows.Forms.Panel();
            this.btnMobo5 = new System.Windows.Forms.Button();
            this.panel11 = new System.Windows.Forms.Panel();
            this.btnMobo4 = new System.Windows.Forms.Button();
            this.panel12 = new System.Windows.Forms.Panel();
            this.btnMobo3 = new System.Windows.Forms.Button();
            this.panel13 = new System.Windows.Forms.Panel();
            this.btnMobo2 = new System.Windows.Forms.Button();
            this.panel14 = new System.Windows.Forms.Panel();
            this.btnMobo1 = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.btnCpu5 = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.btnCpu4 = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btnCpu3 = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnCpu2 = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnCpu1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.pnlCpu.SuspendLayout();
            this.pnlMobo.SuspendLayout();
            this.pnlMem.SuspendLayout();
            this.pnlGpu.SuspendLayout();
            this.pnlCool.SuspendLayout();
            this.pnlPsu.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel34.SuspendLayout();
            this.panel35.SuspendLayout();
            this.panel36.SuspendLayout();
            this.panel37.SuspendLayout();
            this.panel38.SuspendLayout();
            this.panel29.SuspendLayout();
            this.panel30.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel33.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel25.SuspendLayout();
            this.panel26.SuspendLayout();
            this.panel27.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.pnlOnCase);
            this.panel1.Controls.Add(this.pnlOnPsu);
            this.panel1.Controls.Add(this.pnlOnCool);
            this.panel1.Controls.Add(this.pnlOnGpu);
            this.panel1.Controls.Add(this.pnlOnMem);
            this.panel1.Controls.Add(this.pnlOnMobo);
            this.panel1.Controls.Add(this.pnlOnCpu);
            this.panel1.Controls.Add(this.button7);
            this.panel1.Controls.Add(this.button6);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(458, 1321);
            this.panel1.TabIndex = 0;
            // 
            // pnlOnCase
            // 
            this.pnlOnCase.BackColor = System.Drawing.Color.White;
            this.pnlOnCase.Location = new System.Drawing.Point(438, 985);
            this.pnlOnCase.Margin = new System.Windows.Forms.Padding(6);
            this.pnlOnCase.Name = "pnlOnCase";
            this.pnlOnCase.Size = new System.Drawing.Size(20, 83);
            this.pnlOnCase.TabIndex = 13;
            // 
            // pnlOnPsu
            // 
            this.pnlOnPsu.BackColor = System.Drawing.Color.White;
            this.pnlOnPsu.Location = new System.Drawing.Point(438, 850);
            this.pnlOnPsu.Margin = new System.Windows.Forms.Padding(6);
            this.pnlOnPsu.Name = "pnlOnPsu";
            this.pnlOnPsu.Size = new System.Drawing.Size(20, 83);
            this.pnlOnPsu.TabIndex = 12;
            // 
            // pnlOnCool
            // 
            this.pnlOnCool.BackColor = System.Drawing.Color.White;
            this.pnlOnCool.Location = new System.Drawing.Point(438, 708);
            this.pnlOnCool.Margin = new System.Windows.Forms.Padding(6);
            this.pnlOnCool.Name = "pnlOnCool";
            this.pnlOnCool.Size = new System.Drawing.Size(20, 83);
            this.pnlOnCool.TabIndex = 11;
            // 
            // pnlOnGpu
            // 
            this.pnlOnGpu.BackColor = System.Drawing.Color.White;
            this.pnlOnGpu.Location = new System.Drawing.Point(438, 562);
            this.pnlOnGpu.Margin = new System.Windows.Forms.Padding(6);
            this.pnlOnGpu.Name = "pnlOnGpu";
            this.pnlOnGpu.Size = new System.Drawing.Size(20, 83);
            this.pnlOnGpu.TabIndex = 10;
            // 
            // pnlOnMem
            // 
            this.pnlOnMem.BackColor = System.Drawing.Color.White;
            this.pnlOnMem.Location = new System.Drawing.Point(438, 433);
            this.pnlOnMem.Margin = new System.Windows.Forms.Padding(6);
            this.pnlOnMem.Name = "pnlOnMem";
            this.pnlOnMem.Size = new System.Drawing.Size(20, 83);
            this.pnlOnMem.TabIndex = 9;
            // 
            // pnlOnMobo
            // 
            this.pnlOnMobo.BackColor = System.Drawing.Color.White;
            this.pnlOnMobo.Location = new System.Drawing.Point(438, 302);
            this.pnlOnMobo.Margin = new System.Windows.Forms.Padding(6);
            this.pnlOnMobo.Name = "pnlOnMobo";
            this.pnlOnMobo.Size = new System.Drawing.Size(20, 83);
            this.pnlOnMobo.TabIndex = 8;
            // 
            // pnlOnCpu
            // 
            this.pnlOnCpu.BackColor = System.Drawing.Color.White;
            this.pnlOnCpu.Location = new System.Drawing.Point(438, 171);
            this.pnlOnCpu.Margin = new System.Windows.Forms.Padding(6);
            this.pnlOnCpu.Name = "pnlOnCpu";
            this.pnlOnCpu.Size = new System.Drawing.Size(20, 83);
            this.pnlOnCpu.TabIndex = 7;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Black;
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.SystemColors.Control;
            this.button7.Image = global::WindowsFormsApp4.Properties.Resources.chassis_50;
            this.button7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button7.Location = new System.Drawing.Point(0, 985);
            this.button7.Margin = new System.Windows.Forms.Padding(6);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(458, 83);
            this.button7.TabIndex = 6;
            this.button7.Text = "  Chassis";
            this.button7.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click_1);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Black;
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.SystemColors.Control;
            this.button6.Image = global::WindowsFormsApp4.Properties.Resources.power_supply_50;
            this.button6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button6.Location = new System.Drawing.Point(0, 850);
            this.button6.Margin = new System.Windows.Forms.Padding(6);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(458, 83);
            this.button6.TabIndex = 5;
            this.button6.Text = "  Power Supply";
            this.button6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click_1);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Black;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.SystemColors.Control;
            this.button5.Image = global::WindowsFormsApp4.Properties.Resources.case_fan_50;
            this.button5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.Location = new System.Drawing.Point(6, 708);
            this.button5.Margin = new System.Windows.Forms.Padding(6);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(458, 83);
            this.button5.TabIndex = 4;
            this.button5.Text = "  Cooling";
            this.button5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click_1);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Black;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.SystemColors.Control;
            this.button4.Image = global::WindowsFormsApp4.Properties.Resources.video_card_50;
            this.button4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button4.Location = new System.Drawing.Point(0, 562);
            this.button4.Margin = new System.Windows.Forms.Padding(6);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(458, 83);
            this.button4.TabIndex = 3;
            this.button4.Text = "  Graphics Card";
            this.button4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Black;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.SystemColors.Control;
            this.button3.Image = global::WindowsFormsApp4.Properties.Resources.memory_50;
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.Location = new System.Drawing.Point(0, 433);
            this.button3.Margin = new System.Windows.Forms.Padding(6);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(458, 83);
            this.button3.TabIndex = 2;
            this.button3.Text = "  Memory";
            this.button3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Black;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.Control;
            this.button2.Image = global::WindowsFormsApp4.Properties.Resources.motherboard_50;
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(0, 302);
            this.button2.Margin = new System.Windows.Forms.Padding(6);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(458, 83);
            this.button2.TabIndex = 1;
            this.button2.Text = "  Motherboard";
            this.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Black;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.Control;
            this.button1.Image = global::WindowsFormsApp4.Properties.Resources.processor_50;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(0, 171);
            this.button1.Margin = new System.Windows.Forms.Padding(6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(458, 83);
            this.button1.TabIndex = 0;
            this.button1.Text = "  Processor";
            this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.button9);
            this.panel2.Controls.Add(this.button8);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(458, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(6);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1870, 160);
            this.panel2.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1581, 93);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 25);
            this.label3.TabIndex = 4;
            this.label3.Text = "label3";
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(994, 66);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(169, 72);
            this.button9.TabIndex = 3;
            this.button9.Text = "Purchase History";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.Button9_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(1209, 66);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(171, 72);
            this.button8.TabIndex = 2;
            this.button8.Text = "Cart";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.Button8_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(1408, 87);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(174, 33);
            this.label2.TabIndex = 1;
            this.label2.Text = "Logged in as:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Trebuchet MS", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(30, 40);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(616, 89);
            this.label1.TabIndex = 0;
            this.label1.Text = "Components Core";
            // 
            // pnlCpu
            // 
            this.pnlCpu.Controls.Add(this.pnlMobo);
            this.pnlCpu.Controls.Add(this.panel8);
            this.pnlCpu.Controls.Add(this.panel7);
            this.pnlCpu.Controls.Add(this.panel6);
            this.pnlCpu.Controls.Add(this.panel5);
            this.pnlCpu.Controls.Add(this.panel4);
            this.pnlCpu.Location = new System.Drawing.Point(470, 171);
            this.pnlCpu.Margin = new System.Windows.Forms.Padding(6);
            this.pnlCpu.Name = "pnlCpu";
            this.pnlCpu.Size = new System.Drawing.Size(1870, 1162);
            this.pnlCpu.TabIndex = 2;
            this.pnlCpu.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // pnlMobo
            // 
            this.pnlMobo.Controls.Add(this.pnlMem);
            this.pnlMobo.Controls.Add(this.panel10);
            this.pnlMobo.Controls.Add(this.panel11);
            this.pnlMobo.Controls.Add(this.panel12);
            this.pnlMobo.Controls.Add(this.panel13);
            this.pnlMobo.Controls.Add(this.panel14);
            this.pnlMobo.Location = new System.Drawing.Point(0, 0);
            this.pnlMobo.Margin = new System.Windows.Forms.Padding(6);
            this.pnlMobo.Name = "pnlMobo";
            this.pnlMobo.Size = new System.Drawing.Size(1870, 1162);
            this.pnlMobo.TabIndex = 5;
            // 
            // pnlMem
            // 
            this.pnlMem.Controls.Add(this.pnlGpu);
            this.pnlMem.Controls.Add(this.panel9);
            this.pnlMem.Controls.Add(this.panel15);
            this.pnlMem.Controls.Add(this.panel16);
            this.pnlMem.Controls.Add(this.panel17);
            this.pnlMem.Controls.Add(this.panel18);
            this.pnlMem.Location = new System.Drawing.Point(0, 0);
            this.pnlMem.Margin = new System.Windows.Forms.Padding(6);
            this.pnlMem.Name = "pnlMem";
            this.pnlMem.Size = new System.Drawing.Size(1870, 1162);
            this.pnlMem.TabIndex = 6;
            // 
            // pnlGpu
            // 
            this.pnlGpu.Controls.Add(this.pnlCool);
            this.pnlGpu.Controls.Add(this.panel19);
            this.pnlGpu.Controls.Add(this.panel20);
            this.pnlGpu.Controls.Add(this.panel21);
            this.pnlGpu.Controls.Add(this.panel22);
            this.pnlGpu.Controls.Add(this.panel23);
            this.pnlGpu.Location = new System.Drawing.Point(0, 0);
            this.pnlGpu.Margin = new System.Windows.Forms.Padding(6);
            this.pnlGpu.Name = "pnlGpu";
            this.pnlGpu.Size = new System.Drawing.Size(1870, 1162);
            this.pnlGpu.TabIndex = 7;
            // 
            // pnlCool
            // 
            this.pnlCool.Controls.Add(this.pnlPsu);
            this.pnlCool.Controls.Add(this.panel24);
            this.pnlCool.Controls.Add(this.panel25);
            this.pnlCool.Controls.Add(this.panel26);
            this.pnlCool.Controls.Add(this.panel27);
            this.pnlCool.Controls.Add(this.panel28);
            this.pnlCool.Location = new System.Drawing.Point(0, 0);
            this.pnlCool.Margin = new System.Windows.Forms.Padding(6);
            this.pnlCool.Name = "pnlCool";
            this.pnlCool.Size = new System.Drawing.Size(1870, 1162);
            this.pnlCool.TabIndex = 8;
            // 
            // pnlPsu
            // 
            this.pnlPsu.Controls.Add(this.panel3);
            this.pnlPsu.Controls.Add(this.panel29);
            this.pnlPsu.Controls.Add(this.panel30);
            this.pnlPsu.Controls.Add(this.panel31);
            this.pnlPsu.Controls.Add(this.panel32);
            this.pnlPsu.Controls.Add(this.panel33);
            this.pnlPsu.Location = new System.Drawing.Point(0, 0);
            this.pnlPsu.Margin = new System.Windows.Forms.Padding(6);
            this.pnlPsu.Name = "pnlPsu";
            this.pnlPsu.Size = new System.Drawing.Size(1870, 1162);
            this.pnlPsu.TabIndex = 9;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.panel34);
            this.panel3.Controls.Add(this.panel35);
            this.panel3.Controls.Add(this.panel36);
            this.panel3.Controls.Add(this.panel37);
            this.panel3.Controls.Add(this.panel38);
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(6);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1870, 1162);
            this.panel3.TabIndex = 10;
            // 
            // panel34
            // 
            this.panel34.Controls.Add(this.BtnChassis5);
            this.panel34.Location = new System.Drawing.Point(692, 583);
            this.panel34.Margin = new System.Windows.Forms.Padding(6);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(474, 448);
            this.panel34.TabIndex = 4;
            // 
            // BtnChassis5
            // 
            this.BtnChassis5.FlatAppearance.BorderSize = 0;
            this.BtnChassis5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnChassis5.Image = global::WindowsFormsApp4.Properties.Resources._11_119_348_V01_18;
            this.BtnChassis5.Location = new System.Drawing.Point(6, 6);
            this.BtnChassis5.Margin = new System.Windows.Forms.Padding(6);
            this.BtnChassis5.Name = "BtnChassis5";
            this.BtnChassis5.Size = new System.Drawing.Size(462, 442);
            this.BtnChassis5.TabIndex = 0;
            this.BtnChassis5.Text = "Cooler Master MasterBox E300L";
            this.BtnChassis5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.BtnChassis5.UseVisualStyleBackColor = true;
            this.BtnChassis5.Click += new System.EventHandler(this.BtnChassis5_Click);
            // 
            // panel35
            // 
            this.panel35.Controls.Add(this.BtnChassis4);
            this.panel35.Location = new System.Drawing.Point(46, 577);
            this.panel35.Margin = new System.Windows.Forms.Padding(6);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(474, 448);
            this.panel35.TabIndex = 3;
            // 
            // BtnChassis4
            // 
            this.BtnChassis4.FlatAppearance.BorderSize = 0;
            this.BtnChassis4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnChassis4.Image = global::WindowsFormsApp4.Properties.Resources._11_139_118_V01_18;
            this.BtnChassis4.Location = new System.Drawing.Point(6, 6);
            this.BtnChassis4.Margin = new System.Windows.Forms.Padding(6);
            this.BtnChassis4.Name = "BtnChassis4";
            this.BtnChassis4.Size = new System.Drawing.Size(462, 442);
            this.BtnChassis4.TabIndex = 0;
            this.BtnChassis4.Text = "Corsair Carbide Series 275R ";
            this.BtnChassis4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.BtnChassis4.UseVisualStyleBackColor = true;
            this.BtnChassis4.Click += new System.EventHandler(this.BtnChassis4_Click);
            // 
            // panel36
            // 
            this.panel36.Controls.Add(this.BtnChassis3);
            this.panel36.Location = new System.Drawing.Point(1336, 37);
            this.panel36.Margin = new System.Windows.Forms.Padding(6);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(474, 448);
            this.panel36.TabIndex = 2;
            // 
            // BtnChassis3
            // 
            this.BtnChassis3.FlatAppearance.BorderSize = 0;
            this.BtnChassis3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnChassis3.Image = global::WindowsFormsApp4.Properties.Resources._11_133_359_V16_18;
            this.BtnChassis3.Location = new System.Drawing.Point(6, 0);
            this.BtnChassis3.Margin = new System.Windows.Forms.Padding(6);
            this.BtnChassis3.Name = "BtnChassis3";
            this.BtnChassis3.Size = new System.Drawing.Size(462, 442);
            this.BtnChassis3.TabIndex = 0;
            this.BtnChassis3.Text = "Thermaltake View 71 RGB";
            this.BtnChassis3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.BtnChassis3.UseVisualStyleBackColor = true;
            this.BtnChassis3.Click += new System.EventHandler(this.BtnChassis3_Click);
            // 
            // panel37
            // 
            this.panel37.Controls.Add(this.BtnChassis2);
            this.panel37.Location = new System.Drawing.Point(692, 37);
            this.panel37.Margin = new System.Windows.Forms.Padding(6);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(474, 448);
            this.panel37.TabIndex = 1;
            // 
            // BtnChassis2
            // 
            this.BtnChassis2.FlatAppearance.BorderSize = 0;
            this.BtnChassis2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnChassis2.Image = global::WindowsFormsApp4.Properties.Resources._11_139_087_V01_18;
            this.BtnChassis2.Location = new System.Drawing.Point(6, 6);
            this.BtnChassis2.Margin = new System.Windows.Forms.Padding(6);
            this.BtnChassis2.Name = "BtnChassis2";
            this.BtnChassis2.Size = new System.Drawing.Size(462, 442);
            this.BtnChassis2.TabIndex = 0;
            this.BtnChassis2.Text = " CORSAIR Crystal Series 570X RGB";
            this.BtnChassis2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.BtnChassis2.UseVisualStyleBackColor = true;
            this.BtnChassis2.Click += new System.EventHandler(this.BtnChassis2_Click);
            // 
            // panel38
            // 
            this.panel38.Controls.Add(this.BtnChassis1);
            this.panel38.Location = new System.Drawing.Point(46, 37);
            this.panel38.Margin = new System.Windows.Forms.Padding(6);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(474, 448);
            this.panel38.TabIndex = 0;
            // 
            // BtnChassis1
            // 
            this.BtnChassis1.FlatAppearance.BorderSize = 0;
            this.BtnChassis1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnChassis1.Image = global::WindowsFormsApp4.Properties.Resources._11_119_349_V13_1_18;
            this.BtnChassis1.Location = new System.Drawing.Point(6, 0);
            this.BtnChassis1.Margin = new System.Windows.Forms.Padding(6);
            this.BtnChassis1.Name = "BtnChassis1";
            this.BtnChassis1.Size = new System.Drawing.Size(462, 442);
            this.BtnChassis1.TabIndex = 0;
            this.BtnChassis1.Text = " Cooler Master MasterCase H500M";
            this.BtnChassis1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.BtnChassis1.UseVisualStyleBackColor = true;
            this.BtnChassis1.Click += new System.EventHandler(this.BtnChassis1_Click);
            // 
            // panel29
            // 
            this.panel29.Controls.Add(this.btnPsu5);
            this.panel29.Location = new System.Drawing.Point(692, 583);
            this.panel29.Margin = new System.Windows.Forms.Padding(6);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(474, 448);
            this.panel29.TabIndex = 4;
            // 
            // btnPsu5
            // 
            this.btnPsu5.FlatAppearance.BorderSize = 0;
            this.btnPsu5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPsu5.Image = global::WindowsFormsApp4.Properties.Resources._17_139_160_Z01_15;
            this.btnPsu5.Location = new System.Drawing.Point(6, 6);
            this.btnPsu5.Margin = new System.Windows.Forms.Padding(6);
            this.btnPsu5.Name = "btnPsu5";
            this.btnPsu5.Size = new System.Drawing.Size(462, 442);
            this.btnPsu5.TabIndex = 0;
            this.btnPsu5.Text = "CORSAIR AX Series AX1000";
            this.btnPsu5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnPsu5.UseVisualStyleBackColor = true;
            this.btnPsu5.Click += new System.EventHandler(this.btnPsu5_Click);
            // 
            // panel30
            // 
            this.panel30.Controls.Add(this.btnPsu4);
            this.panel30.Location = new System.Drawing.Point(46, 577);
            this.panel30.Margin = new System.Windows.Forms.Padding(6);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(474, 448);
            this.panel30.TabIndex = 3;
            // 
            // btnPsu4
            // 
            this.btnPsu4.FlatAppearance.BorderSize = 0;
            this.btnPsu4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPsu4.Image = global::WindowsFormsApp4.Properties.Resources._17_139_204_V01_15;
            this.btnPsu4.Location = new System.Drawing.Point(6, 6);
            this.btnPsu4.Margin = new System.Windows.Forms.Padding(6);
            this.btnPsu4.Name = "btnPsu4";
            this.btnPsu4.Size = new System.Drawing.Size(462, 442);
            this.btnPsu4.TabIndex = 0;
            this.btnPsu4.Text = "CORSAIR HX Series HX1000";
            this.btnPsu4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnPsu4.UseVisualStyleBackColor = true;
            this.btnPsu4.Click += new System.EventHandler(this.btnPsu4_Click);
            // 
            // panel31
            // 
            this.panel31.Controls.Add(this.btnPsu3);
            this.panel31.Location = new System.Drawing.Point(1336, 37);
            this.panel31.Margin = new System.Windows.Forms.Padding(6);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(474, 448);
            this.panel31.TabIndex = 2;
            // 
            // btnPsu3
            // 
            this.btnPsu3.FlatAppearance.BorderSize = 0;
            this.btnPsu3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPsu3.Image = global::WindowsFormsApp4.Properties.Resources._17_438_013_08_15;
            this.btnPsu3.Location = new System.Drawing.Point(6, 0);
            this.btnPsu3.Margin = new System.Windows.Forms.Padding(6);
            this.btnPsu3.Name = "btnPsu3";
            this.btnPsu3.Size = new System.Drawing.Size(462, 442);
            this.btnPsu3.TabIndex = 0;
            this.btnPsu3.Text = "Cooler EVGA SuperNOVA 1000 P2";
            this.btnPsu3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnPsu3.UseVisualStyleBackColor = true;
            this.btnPsu3.Click += new System.EventHandler(this.btnPsu3_Click);
            // 
            // panel32
            // 
            this.panel32.Controls.Add(this.btnPsu2);
            this.panel32.Location = new System.Drawing.Point(692, 37);
            this.panel32.Margin = new System.Windows.Forms.Padding(6);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(474, 448);
            this.panel32.TabIndex = 1;
            // 
            // btnPsu2
            // 
            this.btnPsu2.FlatAppearance.BorderSize = 0;
            this.btnPsu2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPsu2.Image = global::WindowsFormsApp4.Properties.Resources._17_139_210_Z90_1_15;
            this.btnPsu2.Location = new System.Drawing.Point(6, 6);
            this.btnPsu2.Margin = new System.Windows.Forms.Padding(6);
            this.btnPsu2.Name = "btnPsu2";
            this.btnPsu2.Size = new System.Drawing.Size(462, 442);
            this.btnPsu2.TabIndex = 0;
            this.btnPsu2.Text = "CORSAIR TX-M Series TX550M ";
            this.btnPsu2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnPsu2.UseVisualStyleBackColor = true;
            this.btnPsu2.Click += new System.EventHandler(this.btnPsu2_Click);
            // 
            // panel33
            // 
            this.panel33.Controls.Add(this.btnPsu1);
            this.panel33.Location = new System.Drawing.Point(46, 37);
            this.panel33.Margin = new System.Windows.Forms.Padding(6);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(474, 448);
            this.panel33.TabIndex = 0;
            // 
            // btnPsu1
            // 
            this.btnPsu1.FlatAppearance.BorderSize = 0;
            this.btnPsu1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPsu1.Image = global::WindowsFormsApp4.Properties.Resources._17_438_059_13_1_34;
            this.btnPsu1.Location = new System.Drawing.Point(6, 0);
            this.btnPsu1.Margin = new System.Windows.Forms.Padding(6);
            this.btnPsu1.Name = "btnPsu1";
            this.btnPsu1.Size = new System.Drawing.Size(462, 442);
            this.btnPsu1.TabIndex = 0;
            this.btnPsu1.Text = " EVGA 650";
            this.btnPsu1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnPsu1.UseVisualStyleBackColor = true;
            this.btnPsu1.Click += new System.EventHandler(this.btnPsu1_Click);
            // 
            // panel24
            // 
            this.panel24.Controls.Add(this.btnCool5);
            this.panel24.Location = new System.Drawing.Point(692, 583);
            this.panel24.Margin = new System.Windows.Forms.Padding(6);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(474, 448);
            this.panel24.TabIndex = 4;
            // 
            // btnCool5
            // 
            this.btnCool5.FlatAppearance.BorderSize = 0;
            this.btnCool5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCool5.Image = global::WindowsFormsApp4.Properties.Resources.A73M_131908704008915250J2uuQQ6fQR_19;
            this.btnCool5.Location = new System.Drawing.Point(6, 6);
            this.btnCool5.Margin = new System.Windows.Forms.Padding(6);
            this.btnCool5.Name = "btnCool5";
            this.btnCool5.Size = new System.Drawing.Size(462, 442);
            this.btnCool5.TabIndex = 0;
            this.btnCool5.Text = "Cooler Master MasterLiquid ML360R";
            this.btnCool5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnCool5.UseVisualStyleBackColor = true;
            this.btnCool5.Click += new System.EventHandler(this.btnCool5_Click);
            // 
            // panel25
            // 
            this.panel25.Controls.Add(this.btnCool4);
            this.panel25.Location = new System.Drawing.Point(46, 577);
            this.panel25.Margin = new System.Windows.Forms.Padding(6);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(474, 448);
            this.panel25.TabIndex = 3;
            // 
            // btnCool4
            // 
            this.btnCool4.FlatAppearance.BorderSize = 0;
            this.btnCool4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCool4.Image = global::WindowsFormsApp4.Properties.Resources._35_103_252_V01_19;
            this.btnCool4.Location = new System.Drawing.Point(6, 6);
            this.btnCool4.Margin = new System.Windows.Forms.Padding(6);
            this.btnCool4.Name = "btnCool4";
            this.btnCool4.Size = new System.Drawing.Size(462, 442);
            this.btnCool4.TabIndex = 0;
            this.btnCool4.Text = "Cooler Master MasterLiquid Lite 240";
            this.btnCool4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnCool4.UseVisualStyleBackColor = true;
            this.btnCool4.Click += new System.EventHandler(this.btnCool4_Click);
            // 
            // panel26
            // 
            this.panel26.Controls.Add(this.btnCool3);
            this.panel26.Location = new System.Drawing.Point(1336, 37);
            this.panel26.Margin = new System.Windows.Forms.Padding(6);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(474, 448);
            this.panel26.TabIndex = 2;
            // 
            // btnCool3
            // 
            this.btnCool3.FlatAppearance.BorderSize = 0;
            this.btnCool3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCool3.Image = global::WindowsFormsApp4.Properties.Resources._35_103_236_V03_19;
            this.btnCool3.Location = new System.Drawing.Point(6, 0);
            this.btnCool3.Margin = new System.Windows.Forms.Padding(6);
            this.btnCool3.Name = "btnCool3";
            this.btnCool3.Size = new System.Drawing.Size(462, 442);
            this.btnCool3.TabIndex = 0;
            this.btnCool3.Text = "Cooler Master MasterLiquid Lite 120";
            this.btnCool3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnCool3.UseVisualStyleBackColor = true;
            this.btnCool3.Click += new System.EventHandler(this.btnCool3_Click);
            // 
            // panel27
            // 
            this.panel27.Controls.Add(this.btnCool2);
            this.panel27.Location = new System.Drawing.Point(692, 37);
            this.panel27.Margin = new System.Windows.Forms.Padding(6);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(474, 448);
            this.panel27.TabIndex = 1;
            // 
            // btnCool2
            // 
            this.btnCool2.FlatAppearance.BorderSize = 0;
            this.btnCool2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCool2.Image = global::WindowsFormsApp4.Properties.Resources._35_103_263_V03_19;
            this.btnCool2.Location = new System.Drawing.Point(6, 6);
            this.btnCool2.Margin = new System.Windows.Forms.Padding(6);
            this.btnCool2.Name = "btnCool2";
            this.btnCool2.Size = new System.Drawing.Size(462, 442);
            this.btnCool2.TabIndex = 0;
            this.btnCool2.Text = "Cooler Master MasterLiquid ML120R";
            this.btnCool2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnCool2.UseVisualStyleBackColor = true;
            this.btnCool2.Click += new System.EventHandler(this.btnCool2_Click);
            // 
            // panel28
            // 
            this.panel28.Controls.Add(this.btnCool1);
            this.panel28.Location = new System.Drawing.Point(46, 37);
            this.panel28.Margin = new System.Windows.Forms.Padding(6);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(474, 448);
            this.panel28.TabIndex = 0;
            // 
            // btnCool1
            // 
            this.btnCool1.FlatAppearance.BorderSize = 0;
            this.btnCool1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCool1.Image = global::WindowsFormsApp4.Properties.Resources._35_181_151_V01_19;
            this.btnCool1.Location = new System.Drawing.Point(6, 0);
            this.btnCool1.Margin = new System.Windows.Forms.Padding(6);
            this.btnCool1.Name = "btnCool1";
            this.btnCool1.Size = new System.Drawing.Size(462, 442);
            this.btnCool1.TabIndex = 0;
            this.btnCool1.Text = "CORSAIR Hydro Series H100i RGB PLATINUM";
            this.btnCool1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnCool1.UseVisualStyleBackColor = true;
            this.btnCool1.Click += new System.EventHandler(this.btnCool1_Click);
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.btnGpu5);
            this.panel19.Location = new System.Drawing.Point(692, 583);
            this.panel19.Margin = new System.Windows.Forms.Padding(6);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(474, 448);
            this.panel19.TabIndex = 4;
            // 
            // btnGpu5
            // 
            this.btnGpu5.FlatAppearance.BorderSize = 0;
            this.btnGpu5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGpu5.Image = global::WindowsFormsApp4.Properties.Resources._14_137_377_V06_191;
            this.btnGpu5.Location = new System.Drawing.Point(6, 6);
            this.btnGpu5.Margin = new System.Windows.Forms.Padding(6);
            this.btnGpu5.Name = "btnGpu5";
            this.btnGpu5.Size = new System.Drawing.Size(462, 442);
            this.btnGpu5.TabIndex = 0;
            this.btnGpu5.Text = "MSI GeForce RTX 2070";
            this.btnGpu5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnGpu5.UseVisualStyleBackColor = true;
            this.btnGpu5.Click += new System.EventHandler(this.btnGpu5_Click);
            // 
            // panel20
            // 
            this.panel20.Controls.Add(this.btnGpu4);
            this.panel20.Location = new System.Drawing.Point(46, 577);
            this.panel20.Margin = new System.Windows.Forms.Padding(6);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(474, 448);
            this.panel20.TabIndex = 3;
            // 
            // btnGpu4
            // 
            this.btnGpu4.FlatAppearance.BorderSize = 0;
            this.btnGpu4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGpu4.Image = global::WindowsFormsApp4.Properties.Resources._14_125_881_S99_19;
            this.btnGpu4.Location = new System.Drawing.Point(6, 6);
            this.btnGpu4.Margin = new System.Windows.Forms.Padding(6);
            this.btnGpu4.Name = "btnGpu4";
            this.btnGpu4.Size = new System.Drawing.Size(462, 442);
            this.btnGpu4.TabIndex = 0;
            this.btnGpu4.Text = "GIGABYTE GeForce GTX 1060";
            this.btnGpu4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnGpu4.UseVisualStyleBackColor = true;
            this.btnGpu4.Click += new System.EventHandler(this.btnGpu4_Click);
            // 
            // panel21
            // 
            this.panel21.Controls.Add(this.btnGpu3);
            this.panel21.Location = new System.Drawing.Point(1336, 37);
            this.panel21.Margin = new System.Windows.Forms.Padding(6);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(474, 448);
            this.panel21.TabIndex = 2;
            // 
            // btnGpu3
            // 
            this.btnGpu3.FlatAppearance.BorderSize = 0;
            this.btnGpu3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGpu3.Image = global::WindowsFormsApp4.Properties.Resources._14_137_392_V11_19;
            this.btnGpu3.Location = new System.Drawing.Point(6, 0);
            this.btnGpu3.Margin = new System.Windows.Forms.Padding(6);
            this.btnGpu3.Name = "btnGpu3";
            this.btnGpu3.Size = new System.Drawing.Size(462, 442);
            this.btnGpu3.TabIndex = 0;
            this.btnGpu3.Text = "MSI GeForce GTX 1660 Ti";
            this.btnGpu3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnGpu3.UseVisualStyleBackColor = true;
            this.btnGpu3.Click += new System.EventHandler(this.btnGpu3_Click);
            // 
            // panel22
            // 
            this.panel22.Controls.Add(this.btnGpu2);
            this.panel22.Location = new System.Drawing.Point(692, 37);
            this.panel22.Margin = new System.Windows.Forms.Padding(6);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(474, 448);
            this.panel22.TabIndex = 1;
            // 
            // btnGpu2
            // 
            this.btnGpu2.FlatAppearance.BorderSize = 0;
            this.btnGpu2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGpu2.Image = global::WindowsFormsApp4.Properties.Resources._14_487_442_V06_19;
            this.btnGpu2.Location = new System.Drawing.Point(6, 6);
            this.btnGpu2.Margin = new System.Windows.Forms.Padding(6);
            this.btnGpu2.Name = "btnGpu2";
            this.btnGpu2.Size = new System.Drawing.Size(462, 442);
            this.btnGpu2.TabIndex = 0;
            this.btnGpu2.Text = "EVGA GeForce RTX 2060 SC Ultra GAMING";
            this.btnGpu2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnGpu2.UseVisualStyleBackColor = true;
            this.btnGpu2.Click += new System.EventHandler(this.btnGpu2_Click);
            // 
            // panel23
            // 
            this.panel23.Controls.Add(this.btnGpu1);
            this.panel23.Location = new System.Drawing.Point(46, 37);
            this.panel23.Margin = new System.Windows.Forms.Padding(6);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(474, 448);
            this.panel23.TabIndex = 0;
            // 
            // btnGpu1
            // 
            this.btnGpu1.FlatAppearance.BorderSize = 0;
            this.btnGpu1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGpu1.Image = global::WindowsFormsApp4.Properties.Resources._14_126_270_V06_1_19;
            this.btnGpu1.Location = new System.Drawing.Point(6, 0);
            this.btnGpu1.Margin = new System.Windows.Forms.Padding(6);
            this.btnGpu1.Name = "btnGpu1";
            this.btnGpu1.Size = new System.Drawing.Size(462, 442);
            this.btnGpu1.TabIndex = 0;
            this.btnGpu1.Text = "ASUS ROG Strix GeForce RTX 2070";
            this.btnGpu1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnGpu1.UseVisualStyleBackColor = true;
            this.btnGpu1.Click += new System.EventHandler(this.btnGpu1_Click);
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.btnMem5);
            this.panel9.Location = new System.Drawing.Point(692, 583);
            this.panel9.Margin = new System.Windows.Forms.Padding(6);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(474, 448);
            this.panel9.TabIndex = 4;
            // 
            // btnMem5
            // 
            this.btnMem5.FlatAppearance.BorderSize = 0;
            this.btnMem5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMem5.Image = global::WindowsFormsApp4.Properties.Resources._20_164_128_Z01_141;
            this.btnMem5.Location = new System.Drawing.Point(6, 6);
            this.btnMem5.Margin = new System.Windows.Forms.Padding(6);
            this.btnMem5.Name = "btnMem5";
            this.btnMem5.Size = new System.Drawing.Size(462, 442);
            this.btnMem5.TabIndex = 0;
            this.btnMem5.Text = "Ballistix Sport LT 16GB";
            this.btnMem5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnMem5.UseVisualStyleBackColor = true;
            this.btnMem5.Click += new System.EventHandler(this.btnMem5_Click);
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.btnMem4);
            this.panel15.Location = new System.Drawing.Point(46, 577);
            this.panel15.Margin = new System.Windows.Forms.Padding(6);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(474, 448);
            this.panel15.TabIndex = 3;
            // 
            // btnMem4
            // 
            this.btnMem4.FlatAppearance.BorderSize = 0;
            this.btnMem4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMem4.Image = global::WindowsFormsApp4.Properties.Resources._20_164_128_Z01_14;
            this.btnMem4.Location = new System.Drawing.Point(6, 6);
            this.btnMem4.Margin = new System.Windows.Forms.Padding(6);
            this.btnMem4.Name = "btnMem4";
            this.btnMem4.Size = new System.Drawing.Size(462, 442);
            this.btnMem4.TabIndex = 0;
            this.btnMem4.Text = "Ballistix Sport LT 32GB";
            this.btnMem4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnMem4.UseVisualStyleBackColor = true;
            this.btnMem4.Click += new System.EventHandler(this.btnMem4_Click);
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.btnMem3);
            this.panel16.Location = new System.Drawing.Point(1336, 37);
            this.panel16.Margin = new System.Windows.Forms.Padding(6);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(474, 448);
            this.panel16.TabIndex = 2;
            // 
            // btnMem3
            // 
            this.btnMem3.FlatAppearance.BorderSize = 0;
            this.btnMem3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMem3.Image = global::WindowsFormsApp4.Properties.Resources._20_236_454_V02_14;
            this.btnMem3.Location = new System.Drawing.Point(6, 0);
            this.btnMem3.Margin = new System.Windows.Forms.Padding(6);
            this.btnMem3.Name = "btnMem3";
            this.btnMem3.Size = new System.Drawing.Size(462, 442);
            this.btnMem3.TabIndex = 0;
            this.btnMem3.Text = "CORSAIR Vengeance RGB Pro 32GB";
            this.btnMem3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnMem3.UseVisualStyleBackColor = true;
            this.btnMem3.Click += new System.EventHandler(this.btnMem3_Click);
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.btnMem2);
            this.panel17.Location = new System.Drawing.Point(692, 37);
            this.panel17.Margin = new System.Windows.Forms.Padding(6);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(474, 448);
            this.panel17.TabIndex = 1;
            // 
            // btnMem2
            // 
            this.btnMem2.FlatAppearance.BorderSize = 0;
            this.btnMem2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMem2.Image = global::WindowsFormsApp4.Properties.Resources._20_232_787_V11_14;
            this.btnMem2.Location = new System.Drawing.Point(6, 6);
            this.btnMem2.Margin = new System.Windows.Forms.Padding(6);
            this.btnMem2.Name = "btnMem2";
            this.btnMem2.Size = new System.Drawing.Size(462, 442);
            this.btnMem2.TabIndex = 0;
            this.btnMem2.Text = "G.Skill TridentZ Royal Series 16GB";
            this.btnMem2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnMem2.UseVisualStyleBackColor = true;
            this.btnMem2.Click += new System.EventHandler(this.btnMem2_Click);
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.btnMem1);
            this.panel18.Location = new System.Drawing.Point(46, 37);
            this.panel18.Margin = new System.Windows.Forms.Padding(6);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(474, 448);
            this.panel18.TabIndex = 0;
            // 
            // btnMem1
            // 
            this.btnMem1.FlatAppearance.BorderSize = 0;
            this.btnMem1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMem1.Image = global::WindowsFormsApp4.Properties.Resources._20_232_750_01_3_14;
            this.btnMem1.Location = new System.Drawing.Point(6, 0);
            this.btnMem1.Margin = new System.Windows.Forms.Padding(6);
            this.btnMem1.Name = "btnMem1";
            this.btnMem1.Size = new System.Drawing.Size(462, 442);
            this.btnMem1.TabIndex = 0;
            this.btnMem1.Text = "G.SKILL tridentZ RGB Series 32GB";
            this.btnMem1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnMem1.UseVisualStyleBackColor = true;
            this.btnMem1.Click += new System.EventHandler(this.btnMem1_Click);
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.btnMobo5);
            this.panel10.Location = new System.Drawing.Point(692, 583);
            this.panel10.Margin = new System.Windows.Forms.Padding(6);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(474, 448);
            this.panel10.TabIndex = 4;
            // 
            // btnMobo5
            // 
            this.btnMobo5.FlatAppearance.BorderSize = 0;
            this.btnMobo5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMobo5.Image = global::WindowsFormsApp4.Properties.Resources._13_145_090_V01_40;
            this.btnMobo5.Location = new System.Drawing.Point(6, 6);
            this.btnMobo5.Margin = new System.Windows.Forms.Padding(6);
            this.btnMobo5.Name = "btnMobo5";
            this.btnMobo5.Size = new System.Drawing.Size(462, 442);
            this.btnMobo5.TabIndex = 0;
            this.btnMobo5.Text = "GIGABYTE Z390 AORUS ULTRA";
            this.btnMobo5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnMobo5.UseVisualStyleBackColor = true;
            this.btnMobo5.Click += new System.EventHandler(this.btnMobo5_Click);
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.btnMobo4);
            this.panel11.Location = new System.Drawing.Point(46, 577);
            this.panel11.Margin = new System.Windows.Forms.Padding(6);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(474, 448);
            this.panel11.TabIndex = 3;
            // 
            // btnMobo4
            // 
            this.btnMobo4.FlatAppearance.BorderSize = 0;
            this.btnMobo4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMobo4.Image = global::WindowsFormsApp4.Properties.Resources._13_145_089_V08_40;
            this.btnMobo4.Location = new System.Drawing.Point(6, 6);
            this.btnMobo4.Margin = new System.Windows.Forms.Padding(6);
            this.btnMobo4.Name = "btnMobo4";
            this.btnMobo4.Size = new System.Drawing.Size(462, 442);
            this.btnMobo4.TabIndex = 0;
            this.btnMobo4.Text = "GIGABYTE Z390 AORUS MASTER";
            this.btnMobo4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnMobo4.UseVisualStyleBackColor = true;
            this.btnMobo4.Click += new System.EventHandler(this.btnMobo4_Click);
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.btnMobo3);
            this.panel12.Location = new System.Drawing.Point(1336, 37);
            this.panel12.Margin = new System.Windows.Forms.Padding(6);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(474, 448);
            this.panel12.TabIndex = 2;
            // 
            // btnMobo3
            // 
            this.btnMobo3.FlatAppearance.BorderSize = 0;
            this.btnMobo3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMobo3.Image = global::WindowsFormsApp4.Properties.Resources._13_144_214_V01_40;
            this.btnMobo3.Location = new System.Drawing.Point(6, 0);
            this.btnMobo3.Margin = new System.Windows.Forms.Padding(6);
            this.btnMobo3.Name = "btnMobo3";
            this.btnMobo3.Size = new System.Drawing.Size(462, 442);
            this.btnMobo3.TabIndex = 0;
            this.btnMobo3.Text = "MSI MPG Z390M GAMING EDGE";
            this.btnMobo3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnMobo3.UseVisualStyleBackColor = true;
            this.btnMobo3.Click += new System.EventHandler(this.btnMobo3_Click);
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.btnMobo2);
            this.panel13.Location = new System.Drawing.Point(692, 37);
            this.panel13.Margin = new System.Windows.Forms.Padding(6);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(474, 448);
            this.panel13.TabIndex = 1;
            // 
            // btnMobo2
            // 
            this.btnMobo2.FlatAppearance.BorderSize = 0;
            this.btnMobo2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMobo2.Image = global::WindowsFormsApp4.Properties.Resources._13_144_211_V80_40;
            this.btnMobo2.Location = new System.Drawing.Point(6, 6);
            this.btnMobo2.Margin = new System.Windows.Forms.Padding(6);
            this.btnMobo2.Name = "btnMobo2";
            this.btnMobo2.Size = new System.Drawing.Size(462, 442);
            this.btnMobo2.TabIndex = 0;
            this.btnMobo2.Text = "MSI MPG Z390 GAMING PRO CARBON AC";
            this.btnMobo2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnMobo2.UseVisualStyleBackColor = true;
            this.btnMobo2.Click += new System.EventHandler(this.btnMobo2_Click);
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.btnMobo1);
            this.panel14.Location = new System.Drawing.Point(46, 37);
            this.panel14.Margin = new System.Windows.Forms.Padding(6);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(474, 448);
            this.panel14.TabIndex = 0;
            // 
            // btnMobo1
            // 
            this.btnMobo1.FlatAppearance.BorderSize = 0;
            this.btnMobo1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMobo1.Image = global::WindowsFormsApp4.Properties.Resources._13_144_209_V80_40;
            this.btnMobo1.Location = new System.Drawing.Point(6, 0);
            this.btnMobo1.Margin = new System.Windows.Forms.Padding(6);
            this.btnMobo1.Name = "btnMobo1";
            this.btnMobo1.Size = new System.Drawing.Size(462, 442);
            this.btnMobo1.TabIndex = 0;
            this.btnMobo1.Text = "MSI MEG Z390 GODLIKE";
            this.btnMobo1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnMobo1.UseVisualStyleBackColor = true;
            this.btnMobo1.Click += new System.EventHandler(this.btnMobo1_Click);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.btnCpu5);
            this.panel8.Location = new System.Drawing.Point(692, 583);
            this.panel8.Margin = new System.Windows.Forms.Padding(6);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(474, 448);
            this.panel8.TabIndex = 4;
            // 
            // btnCpu5
            // 
            this.btnCpu5.FlatAppearance.BorderSize = 0;
            this.btnCpu5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCpu5.Image = global::WindowsFormsApp4.Properties.Resources._19_118_024_V01_19;
            this.btnCpu5.Location = new System.Drawing.Point(6, 6);
            this.btnCpu5.Margin = new System.Windows.Forms.Padding(6);
            this.btnCpu5.Name = "btnCpu5";
            this.btnCpu5.Size = new System.Drawing.Size(462, 442);
            this.btnCpu5.TabIndex = 0;
            this.btnCpu5.Text = "Intel Core i7-9700";
            this.btnCpu5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnCpu5.UseVisualStyleBackColor = true;
            this.btnCpu5.Click += new System.EventHandler(this.btnCpu5_Click);
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.btnCpu4);
            this.panel7.Location = new System.Drawing.Point(46, 577);
            this.panel7.Margin = new System.Windows.Forms.Padding(6);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(474, 448);
            this.panel7.TabIndex = 3;
            // 
            // btnCpu4
            // 
            this.btnCpu4.FlatAppearance.BorderSize = 0;
            this.btnCpu4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCpu4.Image = global::WindowsFormsApp4.Properties.Resources._19_118_024_V01_19;
            this.btnCpu4.Location = new System.Drawing.Point(6, 6);
            this.btnCpu4.Margin = new System.Windows.Forms.Padding(6);
            this.btnCpu4.Name = "btnCpu4";
            this.btnCpu4.Size = new System.Drawing.Size(462, 442);
            this.btnCpu4.TabIndex = 0;
            this.btnCpu4.Text = "Intel Core i7-9700k";
            this.btnCpu4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnCpu4.UseVisualStyleBackColor = true;
            this.btnCpu4.Click += new System.EventHandler(this.btnCpu4_Click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.btnCpu3);
            this.panel6.Location = new System.Drawing.Point(1336, 37);
            this.panel6.Margin = new System.Windows.Forms.Padding(6);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(474, 448);
            this.panel6.TabIndex = 2;
            // 
            // btnCpu3
            // 
            this.btnCpu3.FlatAppearance.BorderSize = 0;
            this.btnCpu3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCpu3.Image = global::WindowsFormsApp4.Properties.Resources._19_118_023_V01_19;
            this.btnCpu3.Location = new System.Drawing.Point(6, 0);
            this.btnCpu3.Margin = new System.Windows.Forms.Padding(6);
            this.btnCpu3.Name = "btnCpu3";
            this.btnCpu3.Size = new System.Drawing.Size(462, 442);
            this.btnCpu3.TabIndex = 0;
            this.btnCpu3.Text = "Intel Core i9-9900";
            this.btnCpu3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnCpu3.UseVisualStyleBackColor = true;
            this.btnCpu3.Click += new System.EventHandler(this.btnCpu3_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.btnCpu2);
            this.panel5.Location = new System.Drawing.Point(692, 37);
            this.panel5.Margin = new System.Windows.Forms.Padding(6);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(474, 448);
            this.panel5.TabIndex = 1;
            // 
            // btnCpu2
            // 
            this.btnCpu2.FlatAppearance.BorderSize = 0;
            this.btnCpu2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCpu2.Image = global::WindowsFormsApp4.Properties.Resources._19_117_962_Z01_2_19;
            this.btnCpu2.Location = new System.Drawing.Point(6, 6);
            this.btnCpu2.Margin = new System.Windows.Forms.Padding(6);
            this.btnCpu2.Name = "btnCpu2";
            this.btnCpu2.Size = new System.Drawing.Size(462, 442);
            this.btnCpu2.TabIndex = 0;
            this.btnCpu2.Text = "Intel Core i9-9900X";
            this.btnCpu2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnCpu2.UseVisualStyleBackColor = true;
            this.btnCpu2.Click += new System.EventHandler(this.btnCpu2_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btnCpu1);
            this.panel4.Location = new System.Drawing.Point(46, 37);
            this.panel4.Margin = new System.Windows.Forms.Padding(6);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(474, 448);
            this.panel4.TabIndex = 0;
            // 
            // btnCpu1
            // 
            this.btnCpu1.FlatAppearance.BorderSize = 0;
            this.btnCpu1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCpu1.Image = global::WindowsFormsApp4.Properties.Resources.i9900k_50;
            this.btnCpu1.Location = new System.Drawing.Point(6, 6);
            this.btnCpu1.Margin = new System.Windows.Forms.Padding(6);
            this.btnCpu1.Name = "btnCpu1";
            this.btnCpu1.Size = new System.Drawing.Size(462, 442);
            this.btnCpu1.TabIndex = 0;
            this.btnCpu1.Text = "Intel Core i9-9900K";
            this.btnCpu1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.btnCpu1.UseVisualStyleBackColor = true;
            this.btnCpu1.Click += new System.EventHandler(this.btnCpu1_Click);
            // 
            // productForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2328, 1321);
            this.Controls.Add(this.pnlCpu);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "productForm";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.ProductForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.pnlCpu.ResumeLayout(false);
            this.pnlMobo.ResumeLayout(false);
            this.pnlMem.ResumeLayout(false);
            this.pnlGpu.ResumeLayout(false);
            this.pnlCool.ResumeLayout(false);
            this.pnlPsu.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel34.ResumeLayout(false);
            this.panel35.ResumeLayout(false);
            this.panel36.ResumeLayout(false);
            this.panel37.ResumeLayout(false);
            this.panel38.ResumeLayout(false);
            this.panel29.ResumeLayout(false);
            this.panel30.ResumeLayout(false);
            this.panel31.ResumeLayout(false);
            this.panel32.ResumeLayout(false);
            this.panel33.ResumeLayout(false);
            this.panel24.ResumeLayout(false);
            this.panel25.ResumeLayout(false);
            this.panel26.ResumeLayout(false);
            this.panel27.ResumeLayout(false);
            this.panel28.ResumeLayout(false);
            this.panel19.ResumeLayout(false);
            this.panel20.ResumeLayout(false);
            this.panel21.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            this.panel23.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel15.ResumeLayout(false);
            this.panel16.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.panel18.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.panel13.ResumeLayout(false);
            this.panel14.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Panel pnlCpu;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btnCpu2;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button btnCpu3;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button btnCpu4;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Button btnCpu5;
        private System.Windows.Forms.Panel pnlOnCase;
        private System.Windows.Forms.Panel pnlOnPsu;
        private System.Windows.Forms.Panel pnlOnCool;
        private System.Windows.Forms.Panel pnlOnGpu;
        private System.Windows.Forms.Panel pnlOnMem;
        private System.Windows.Forms.Panel pnlOnMobo;
        private System.Windows.Forms.Panel pnlOnCpu;
        private System.Windows.Forms.Panel pnlMobo;
        private System.Windows.Forms.Panel pnlMem;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Button btnMem5;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Button btnMem4;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Button btnMem3;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Button btnMem2;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Button btnMem1;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Button btnMobo5;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Button btnMobo4;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Button btnMobo3;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Button btnMobo2;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Button btnMobo1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnCpu1;
        private System.Windows.Forms.Panel pnlGpu;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Button btnGpu5;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Button btnGpu4;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Button btnGpu3;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Button btnGpu2;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Button btnGpu1;
        private System.Windows.Forms.Panel pnlCool;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Button btnCool5;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Button btnCool4;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Button btnCool3;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Button btnCool2;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Button btnCool1;
        private System.Windows.Forms.Panel pnlPsu;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Button btnPsu5;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Button btnPsu4;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Button btnPsu3;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Button btnPsu2;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Button btnPsu1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.Button BtnChassis5;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Button BtnChassis4;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.Button BtnChassis3;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.Button BtnChassis2;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.Button BtnChassis1;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label label3;
    }
}

