﻿namespace Team_Project
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.FirstName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.LastName = new System.Windows.Forms.TextBox();
            this.Email = new System.Windows.Forms.TextBox();
            this.Password = new System.Windows.Forms.TextBox();
            this.btnCreateAccount = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // FirstName
            // 
            this.FirstName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.FirstName.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.FirstName.Location = new System.Drawing.Point(569, 341);
            this.FirstName.Name = "FirstName";
            this.FirstName.Size = new System.Drawing.Size(251, 31);
            this.FirstName.TabIndex = 0;
            this.FirstName.Text = "First Name";
            this.FirstName.Enter += new System.EventHandler(this.First_Name_Enter);
            this.FirstName.Leave += new System.EventHandler(this.First_Name_Leave);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(458, 208);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(489, 63);
            this.label1.TabIndex = 1;
            this.label1.Text = "Create an Account";
            // 
            // LastName
            // 
            this.LastName.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.LastName.Location = new System.Drawing.Point(569, 413);
            this.LastName.Name = "LastName";
            this.LastName.Size = new System.Drawing.Size(251, 31);
            this.LastName.TabIndex = 2;
            this.LastName.Text = "Last Name";
            this.LastName.Enter += new System.EventHandler(this.Last_Name_Enter);
            this.LastName.Leave += new System.EventHandler(this.Last_Name_Leave);
            // 
            // Email
            // 
            this.Email.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.Email.Location = new System.Drawing.Point(569, 481);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(251, 31);
            this.Email.TabIndex = 3;
            this.Email.Text = "Email Address";
            this.Email.Enter += new System.EventHandler(this.Email_Enter);
            this.Email.Leave += new System.EventHandler(this.Email_Leave);
            // 
            // Password
            // 
            this.Password.ForeColor = System.Drawing.Color.LightSteelBlue;
            this.Password.Location = new System.Drawing.Point(569, 545);
            this.Password.Name = "Password";
            this.Password.Size = new System.Drawing.Size(251, 31);
            this.Password.TabIndex = 4;
            this.Password.Text = "Password";
            this.Password.Click += new System.EventHandler(this.Password_Click);
            this.Password.Enter += new System.EventHandler(this.Password_Enter);
            this.Password.Leave += new System.EventHandler(this.Password_Leave);
            // 
            // btnCreateAccount
            // 
            this.btnCreateAccount.Location = new System.Drawing.Point(603, 623);
            this.btnCreateAccount.Name = "btnCreateAccount";
            this.btnCreateAccount.Size = new System.Drawing.Size(178, 72);
            this.btnCreateAccount.TabIndex = 5;
            this.btnCreateAccount.Text = "Create Account";
            this.btnCreateAccount.UseVisualStyleBackColor = true;
            this.btnCreateAccount.Click += new System.EventHandler(this.BtnCreateAccount_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1433, 950);
            this.Controls.Add(this.btnCreateAccount);
            this.Controls.Add(this.Password);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.LastName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.FirstName);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox FirstName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox LastName;
        private System.Windows.Forms.TextBox Email;
        private System.Windows.Forms.TextBox Password;
        private System.Windows.Forms.Button btnCreateAccount;
    }
}

